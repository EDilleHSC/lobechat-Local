# D: Drive Compliance Watchdog
# Monitors for unauthorized items, structure violations, and suspicious activity

param(
    [switch]$AutoFix = $false,
    [switch]$Strict = $false
)

Write-Host "======================================"
Write-Host "D: Drive Compliance Watchdog"
Write-Host "======================================"
Write-Host ""

$ComplianceIssues = @()
$SystemFiles = @('DumpStack.log.tmp', 'System Volume Information', '$RECYCLE.BIN', 'pagefile.sys', 'hiberfil.sys')
$AuthorizedRootFolders = @('01_SYSTEM-Core', '02_SOFTWARE', '03_DATA-Storage', '04_PROJECTS-Active', '05_AGENTS-AI', '06_SANDBOX-Testing', '07_DOWNLOADS-TEMP-Process', '08_KNOWLEDGE-Base', 'DockerData', 'Temp')

# ============================================
# SCAN 1: Check root directory for violations
# ============================================

Write-Host "SCAN 1: Root Directory Compliance"
Write-Host "================================="

$RootItems = Get-ChildItem -Path "D:\" -ErrorAction SilentlyContinue

foreach ($item in $RootItems) {
    $isAuthorized = $false
    
    # Check if it's an authorized folder
    if ($item.PSIsContainer) {
        if ($AuthorizedRootFolders -contains $item.Name) {
            $isAuthorized = $true
        }
    }
    # Check if it's a system file
    elseif ($SystemFiles -contains $item.Name) {
        $isAuthorized = $true
    }
    # Check if it's an authorized root file (.md, .txt documentation)
    elseif ($item.Name -match '\.md$|\.txt$|README|MANIFEST') {
        $isAuthorized = $true
    }
    
    if (-not $isAuthorized) {
        $ComplianceIssues += @{
            Type = "UNAUTHORIZED_ROOT_ITEM"
            Name = $item.Name
            Path = $item.FullName
            Severity = "HIGH"
            Action = "Move to appropriate numbered folder or delete"
        }
        Write-Host "⚠️  UNAUTHORIZED: $($item.Name)" -ForegroundColor Yellow
    }
    else {
        Write-Host "✅ OK: $($item.Name)" -ForegroundColor Green
    }
}

Write-Host ""

# ============================================
# SCAN 2: Check naming convention compliance
# ============================================

Write-Host "SCAN 2: Naming Convention Compliance"
Write-Host "===================================="

$TopFolders = Get-ChildItem -Path "D:\" -Directory -ErrorAction SilentlyContinue | Where-Object {$_.Name -notmatch '^\$|^System'}

foreach ($folder in $TopFolders) {
    if ($folder.Name -notmatch '^0[1-8]_' -and $folder.Name -notin @('DockerData', 'Temp')) {
        $ComplianceIssues += @{
            Type = "NAMING_VIOLATION"
            Name = $folder.Name
            Path = $folder.FullName
            Severity = "MEDIUM"
            Action = "Rename to follow 0X_FolderName pattern"
        }
        Write-Host "⚠️  NAMING ISSUE: $($folder.Name) (should be 0X_...)" -ForegroundColor Yellow
    }
    else {
        Write-Host "✅ OK: $($folder.Name)" -ForegroundColor Green
    }
}

Write-Host ""

# ============================================
# SCAN 3: Check for suspicious file types
# ============================================

Write-Host "SCAN 3: Suspicious File Detection"
Write-Host "=================================="

$SuspiciousPatterns = @('*.exe', '*.dll', '*.sys', '*.driver', '*.scr', '*.vbs', '*.bat', '*.cmd')
$SuspiciousFiles = @()

foreach ($pattern in $SuspiciousPatterns) {
    $found = Get-ChildItem -Path "D:\" -Recurse -Filter $pattern -ErrorAction SilentlyContinue
    if ($found) {
        foreach ($file in $found) {
            # Check if it's in authorized folders
            if ($file.FullName -match '02_SOFTWARE|Scripts' -or $file.Name -match 'run_|start_|setup_') {
                Write-Host "✅ AUTHORIZED: $($file.Name)" -ForegroundColor Green
            }
            else {
                $ComplianceIssues += @{
                    Type = "SUSPICIOUS_FILE"
                    Name = $file.Name
                    Path = $file.FullName
                    Severity = "CRITICAL"
                    Action = "Review and confirm safety"
                }
                Write-Host "⚠️  SUSPICIOUS: $($file.Name) in $($file.DirectoryName)" -ForegroundColor Red
            }
        }
    }
}

Write-Host ""

# ============================================
# SCAN 4: Check for unauthorized programs
# ============================================

Write-Host "SCAN 4: Unauthorized Program Detection"
Write-Host "======================================"

$UnauthorizedPrograms = @('PUP', 'adware', 'spyware', 'malware', 'crypto', 'miner')
$FoundPrograms = @()

# Check installed programs
$InstalledPrograms = Get-ItemProperty HKLM:\Software\Microsoft\Windows\CurrentVersion\Uninstall\* -ErrorAction SilentlyContinue

foreach ($program in $InstalledPrograms) {
    foreach ($pattern in $UnauthorizedPrograms) {
        if ($program.DisplayName -match $pattern) {
            $ComplianceIssues += @{
                Type = "UNAUTHORIZED_PROGRAM"
                Name = $program.DisplayName
                Path = "Registry: HKLM:\Software\Microsoft\Windows\CurrentVersion\Uninstall\"
                Severity = "CRITICAL"
                Action = "Uninstall immediately"
            }
            Write-Host "⚠️  UNAUTHORIZED PROGRAM: $($program.DisplayName)" -ForegroundColor Red
        }
    }
}

if ($FoundPrograms.Count -eq 0) {
    Write-Host "✅ No unauthorized programs detected" -ForegroundColor Green
}

Write-Host ""

# ============================================
# SUMMARY & REPORT
# ============================================

Write-Host "======================================"
Write-Host "COMPLIANCE REPORT"
Write-Host "======================================"
Write-Host ""

if ($ComplianceIssues.Count -eq 0) {
    Write-Host "✅ SYSTEM COMPLIANT - No issues found!" -ForegroundColor Green
}
else {
    Write-Host "⚠️  COMPLIANCE ISSUES FOUND: $($ComplianceIssues.Count)" -ForegroundColor Yellow
    Write-Host ""
    
    foreach ($issue in $ComplianceIssues) {
        $color = if ($issue.Severity -eq "CRITICAL") { "Red" } elseif ($issue.Severity -eq "HIGH") { "Yellow" } else { "Cyan" }
        
        Write-Host "[$($issue.Severity)] $($issue.Type)" -ForegroundColor $color
        Write-Host "  Item: $($issue.Name)"
        Write-Host "  Path: $($issue.Path)"
        Write-Host "  Action: $($issue.Action)"
        Write-Host ""
    }
}

Write-Host "======================================"
Write-Host "Scan completed: $(Get-Date)" -ForegroundColor Cyan
Write-Host "======================================"

# ============================================
# AUTO-FIX (optional)
# ============================================

if ($AutoFix -and $ComplianceIssues.Count -gt 0) {
    Write-Host ""
    Write-Host "Running AUTO-FIX (be careful!)..."
    Write-Host ""
    
    foreach ($issue in $ComplianceIssues) {
        if ($issue.Type -eq "SUSPICIOUS_FILE") {
            Write-Host "⚠️  REVIEW NEEDED: $($issue.Name) - skipping auto-fix for safety" -ForegroundColor Red
        }
        elseif ($issue.Type -eq "UNAUTHORIZED_PROGRAM") {
            Write-Host "⚠️  MANUAL ACTION NEEDED: Uninstall $($issue.Name)" -ForegroundColor Red
        }
    }
}

# ============================================
# Export report
# ============================================

$ReportPath = "D:\01_SYSTEM-Core\Logs\compliance_report_$(Get-Date -Format 'yyyyMMdd_HHmmss').txt"
$ComplianceIssues | ConvertTo-Json | Out-File -FilePath $ReportPath

Write-Host ""
Write-Host "Report saved to: $ReportPath" -ForegroundColor Cyan
