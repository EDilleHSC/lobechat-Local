# VBoarder Core Compliance Standard

**Version:** 2.0  
**Last Updated:** December 11, 2025  
**Maintainer:** Eric (Human) + VBoarder Agent System  
**Status:** 99/100 compliance (production-ready)

---

## Executive Summary

This document defines the organizational and operational standards for Eric's D: drive system. All AI agents, external tools, and future modifications MUST follow these standards.

**Failure to comply risks:**
- System corruption
- Lost work
- Agent conflicts
- Workflow disruption

---

## Section 1: Folder Structure (MANDATORY)

### Authorized Top-Level Folders

```
D:\
├── 01_SYSTEM-Core/
│   Purpose: System infrastructure, Docker, configs, logs
│   Contains: DockerData/, Logs/, system files
│   Access: Read/Execute (restricted write)
│   Who: System services, Docker, Navi agent
│
├── 02_SOFTWARE/
│   Purpose: Applications, development tools, utilities
│   Contains: Ollama/, LMStudio/, Scripts/, DevTools
│   Access: Full
│   Who: Developers, installation scripts
│
├── 03_DATA-Storage/
│   Purpose: Archives, backups, historical data
│   Contains: Archives/, Backups/, Historical records
│   Access: Read-heavy (occasional writes)
│   Who: Backup agents, archival processes
│
├── 04_PROJECTS-Active/
│   Purpose: Current active projects and work
│   Contains: Project folders, source code, deliverables
│   Access: Full (with version control)
│   Who: Developers, project managers
│
├── 05_AGENTS-AI/
│   Purpose: All VBoarder AI agent code and config
│   Contains: 17 AI agent folders, configurations
│   Access: Full (agents modify own configs)
│   Who: VBoarder agents, developers
│
├── 06_SANDBOX-Testing/
│   Purpose: Experimental work, testing, POCs
│   Contains: Test projects, experimental scripts
│   Access: Full (no restrictions)
│   Who: Developers, testing agents
│
├── 07_DOWNLOADS-TEMP-Process/
│   Purpose: Temporary files, downloads, processing
│   Contains: Temp files, processing workspace
│   Access: Full (auto-cleanup)
│   Who: Any process needing temporary space
│
└── 08_KNOWLEDGE-Base/
    Purpose: Documentation, guides, reference material
    Contains: .md files, guides, API docs, procedures
    Access: Read-heavy (restricted writes)
    Who: All agents, developers (for reference)
```

### System-Required Root Items (DO NOT MOVE)

- `DockerData/` - Docker volume data (in use)
- `Temp/` - Windows system temporary files
- `DumpStack.log.tmp` - Windows crash dump
- `System Volume Information/` - Windows system folder
- `$RECYCLE.BIN/` - Windows recycle bin
- `pagefile.sys` - Windows virtual memory
- `hiberfil.sys` - Windows hibernation file (if present)

---

## Section 2: Naming Conventions (MANDATORY)

### Folder Naming Rules

**Pattern:** `0X_FolderName`

**Rules:**
- Must start with number 01-08
- Underscore separator (no hyphens, no spaces)
- PascalCase after underscore
- No special characters
- Max 50 characters total

**Examples:**
- ✅ `02_SOFTWARE`
- ✅ `05_AGENTS-AI` (hyphen in name is OK, not in prefix)
- ✅ `04_PROJECTS-Active`
- ❌ `02-SOFTWARE` (wrong format)
- ❌ `02 SOFTWARE` (spaces not allowed)
- ❌ `Tools` (missing number)
- ❌ `SOFTWARE-02` (number in wrong position)

### File Naming Rules

**Scripts:** `action_description.ps1` or `.bat`
- Examples: `run_compliance_check.ps1`, `start_services.bat`

**Documentation:** `TOPIC_description.md`
- Examples: `SYSTEM_ARCHITECTURE.md`, `API_ENDPOINTS.md`

**Config Files:** `config.json`, `settings.txt`

**Data Files:** `data_YYYYMMDD.csv`, `backup_YYYYMMDD.zip`

---

## Section 3: Authorization Rules

### Who Can Do What

**Eric (Human Owner):**
- Full access to everything
- Can reorganize at will
- Final approval on all changes
- Sets new standards

**VBoarder Agents:**
- Read access: All folders
- Write access: Only their own folder (05_AGENTS-AI/[AgentName]/)
- Write access: Logs folder (01_SYSTEM-Core/Logs/)
- Can call Navi receptionist for file operations

**External AI Agents (like me):**
- Read access: All folders
- Write access: ONLY with explicit permission
- Must ask before making changes
- Must reference this document

**Automated Services:**
- Docker: 01_SYSTEM-Core/ only
- Ollama: 02_SOFTWARE/Ollama only
- LobeChat: Multiple (defined separately)

---

## Section 4: Operational Standards

### Daily Operations

**Before making ANY change:**
1. Determine which folder it belongs in (reference Section 1)
2. Check naming conventions (Section 2)
3. Verify you have authorization (Section 3)
4. Ask Eric if unsure
5. Document the change

### Workflow Rules

**File Creation:**
- Always create in correct folder immediately
- Don't create in root, move later
- Follow naming conventions
- Document purpose in file

**Installation:**
- Software → 02_SOFTWARE
- Tools → 02_SOFTWARE/Tools or Scripts
- Documentation → 08_KNOWLEDGE-Base
- Never install to root level

**Reorganization:**
- Only Eric can reorganize top-level
- Agents can organize their own folders
- External AI must ask permission first
- Document all changes

---

## Section 5: VBoarder Agent Specifics

### Agent Storage Requirements

**Each agent must:**
- Have folder in 05_AGENTS-AI/[AgentName]/
- Store config in own folder
- Create logs in 01_SYSTEM-Core/Logs/
- Follow naming conventions
- Not touch other agents' folders

### Current Agents (17 Total)

- Navi Thompson (Receptionist)
- Money Penny (Executive Assistant)
- Bernard Giyfoyle (CTO)
- AIR (Archivist & Intelligence)
- [13 others - documented separately]

### Agent Communication

- Via LobeChat (localhost:3210)
- Via MCP protocol
- Via system logs
- Never direct file access to other agents

---

## Section 6: Compliance Monitoring

### Automated Watchdog

**Script:** `compliance_watchdog.ps1`

**Runs:** Daily (scheduled or on-demand)

**Checks:**
- Unauthorized root items
- Naming violations
- Suspicious files
- Unauthorized programs
- Structure integrity

**Reports:** Saved to 01_SYSTEM-Core/Logs/

### Manual Audits

**Frequency:** Monthly (first Monday)

**Process:**
1. Run compliance watchdog
2. Review report
3. Fix violations
4. Document changes
5. Archive report

---

## Section 7: Emergency Procedures

### If Compliance Broken

**Step 1:** Don't panic
**Step 2:** Run compliance watchdog
**Step 3:** Review issues
**Step 4:** Contact Eric immediately
**Step 5:** Follow Eric's instructions

### If Unauthorized Item Found

**Critical Files (exe, dll, sys):**
- Isolate to 06_SANDBOX-Testing
- Don't execute
- Scan with antivirus
- Report to Eric

**Unauthorized Programs:**
- Don't use
- Uninstall immediately
- Report to Eric

---

## Section 8: Dyslexia-Friendly Standards

**All agents MUST follow:**
- Large fonts in documentation (18pt+ when possible)
- High contrast (dark backgrounds, light text)
- Proper spacing (blank lines between sections)
- Clear structure (headers, bullets, numbered lists)
- Simple language (short sentences, clear meaning)

---

## Section 9: Future Modifications

### Adding New Standards

**Process:**
1. Propose to Eric
2. Document rationale
3. Update this document
4. Communicate to all agents
5. Archive old version

### Removing Standards

**Process:**
1. Propose to Eric
2. Document why
3. Update this document
4. Communicate to all agents

---

## Section 10: Compliance Checklist

### For Every Change

- [ ] Determined correct folder
- [ ] Follows naming conventions
- [ ] Have authorization
- [ ] Used proper tools/procedures
- [ ] Documented change
- [ ] Ran compliance check
- [ ] Reported to Eric (if needed)

### Monthly Audit

- [ ] Ran compliance watchdog
- [ ] Reviewed all issues
- [ ] Fixed violations
- [ ] Documented audit
- [ ] Archived report
- [ ] Notified Eric of status

---

## Compliance Status

**Current Score:** 99/100

**Last Audit:** December 11, 2025

**Issues:** 
- DockerData (system-required exception)
- Temp folder (system-required exception)

**Status:** ✅ PRODUCTION-READY

---

## Questions?

**Reference:** D_DRIVE_README.md (for new agents)

**Contact:** Eric

**Script:** compliance_watchdog.ps1

**Emergency:** Stop work, document issue, contact Eric

---

**This document is BINDING for all work on this system.**

**Violations risk system integrity and workflow disruption.**

**Questions > Assumptions. Always ask if unsure.**

🔒 **COMPLIANCE IS NON-NEGOTIABLE** 🔒
