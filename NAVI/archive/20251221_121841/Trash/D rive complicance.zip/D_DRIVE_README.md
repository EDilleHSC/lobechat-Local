# D: Drive System Architecture

**CRITICAL: Read this before making ANY changes**

This is Eric's organized development and business system.

---

## Folder Structure (STRICT Compliance Required)

```
D:\
├── 01_SYSTEM-Core/          → System infrastructure, configs, Docker
├── 02_SOFTWARE/             → Applications, tools, Ollama, LMStudio
├── 03_DATA-Storage/         → Archives, backups, historical data
├── 04_PROJECTS-Active/      → Current work and projects
├── 05_AGENTS-AI/            → VBoarder AI agents (17 total)
├── 06_SANDBOX-Testing/      → Experimental work, testing only
├── 07_DOWNLOADS-TEMP/       → Temporary downloads, processing
└── 08_KNOWLEDGE-Base/       → Documentation, guides, reference
```

---

## Critical Rules for ALL AI Agents

**MANDATORY - DO NOT VIOLATE:**

1. **Never create items in root directory**
   - Every file/folder must be in numbered folder
   - No exceptions

2. **Follow naming conventions**
   - Numbered folders only: 01_ through 08_
   - Use underscores for spacing: 02_SOFTWARE
   - No hyphens, no mixed naming

3. **Respect existing structure**
   - Don't reorganize without permission
   - Don't create new top-level folders
   - Don't move system files

4. **Keep system files untouched**
   - DockerData/ (running system)
   - Temp/ (Windows system)
   - DumpStack.log.tmp (Windows log)
   - System Volume Information
   - $RECYCLE.BIN
   - pagefile.sys

---

## Where Things Belong

**Application/Tool Installation:**
→ 02_SOFTWARE/

**Project Files:**
→ 04_PROJECTS-Active/

**AI Agent Code/Config:**
→ 05_AGENTS-AI/

**Documentation:**
→ 08_KNOWLEDGE-Base/

**Experimental Work:**
→ 06_SANDBOX-Testing/

**Data/Archives:**
→ 03_DATA-Storage/

**System Config/Docker:**
→ 01_SYSTEM-Core/

**Temporary Files:**
→ 07_DOWNLOADS-TEMP/

---

## VBoarder Agent System

**Total Agents:** 17

**Key Agents:**
- Navi Thompson (Receptionist/File Intake)
- Money Penny (Executive Assistant)
- Bernard Giyfoyle (CTO Agent)
- AIR (Archivist & Intelligence Research)
- + 13 others in 05_AGENTS-AI folder

**All agents MUST:**
- Store config in 05_AGENTS-AI/
- Log to 01_SYSTEM-Core/Logs/
- Access tools via LobeChat (localhost:3210)
- Respect GTD zero-inbox workflow

---

## Active Services

**Always Running:**
- LobeChat (localhost:3210)
- Ollama (local LLM inference)
- Docker services (6 containers)

**Configuration:**
- Navi MCP: http://localhost:3002/mcp
- System uses dyslexia-friendly formatting
- All output must be clean, organized, readable

---

## Eric's Development Context

**Role:** CTO & Co-founder, Home Stagers Choice
**Background:** Gulf War Marine, 1800+ home builds, extensive AI/Docker expertise
**Accessibility:** Dyslexia - requires large fonts (18pt+), high contrast, proper spacing
**Timezone:** Colorado Springs, Colorado
**Current Focus:** VBoarder AI agent system development

---

## When Dropping Into This System

**CHECK THIS FIRST:**

1. Verify you're in D:\ root (not C: or other drives)
2. Respect all numbered folder structure
3. Keep everything OUT of root directory
4. Follow dyslexia-friendly formatting standards
5. Never move or delete system files
6. Always ask before reorganizing
7. Document any changes made

---

## Compliance Status

**Current:** 99/100 (system files exempt)

**Last Updated:** December 11, 2025

**Maintained By:** Eric (Human) + VBoarder Agents

---

## Emergency Contact

If you're an external AI unsure about something:
- Don't guess
- Don't reorganize
- Ask Eric first
- Reference this README

**This system is production-critical.** Mistakes can disrupt active work.

---

**AUTHORIZED MODIFICATIONS ONLY** 🔒
