# YouTube → AIR Knowledge Workflow
## Integration Guide for VBoarder

---

## THE FLOW

```
User provides YouTube URL
    ↓
Transcription Agent extracts transcript
    ↓
AIR receives transcript
    ↓
AIR classifies knowledge type
    ↓
AIR extracts & structures key knowledge
    ↓
AIR archives in appropriate location
    ↓
AIR indexes for search
    ↓
Team can search and reference this knowledge
```

---

## STEP 1: SET UP TRANSCRIPTION AGENT

### Option A: Using youtube-transcript-api (Python)

**Install:**
```bash
pip install youtube-transcript-api
```

**Create transcription endpoint** (`transcribe_youtube.py`):
```python
from youtube_transcript_api import YouTubeTranscriptApi
import json
from urllib.parse import urlparse, parse_qs

def extract_video_id(youtube_url):
    """Extract video ID from YouTube URL"""
    parsed_url = urlparse(youtube_url)
    if parsed_url.hostname == 'youtu.be':
        return parsed_url.path[1:]
    return parse_qs(parsed_url.query).get('v', [None])[0]

def get_transcript(youtube_url):
    """Fetch transcript from YouTube video"""
    try:
        video_id = extract_video_id(youtube_url)
        transcript = YouTubeTranscriptApi.get_transcript(video_id)
        
        # Convert list of dicts to continuous text
        full_transcript = " ".join([item['text'] for item in transcript])
        
        return {
            "status": "success",
            "video_id": video_id,
            "url": youtube_url,
            "transcript": full_transcript,
            "word_count": len(full_transcript.split())
        }
    except Exception as e:
        return {
            "status": "error",
            "message": str(e)
        }

# For testing
if __name__ == "__main__":
    url = input("Enter YouTube URL: ")
    result = get_transcript(url)
    print(json.dumps(result, indent=2))
```

**Test it:**
```bash
python transcribe_youtube.py
# Then paste a YouTube URL when prompted
```

---

## STEP 2: INTEGRATE WITH LOBECHAT

### Option A: Manual Process (Simple)

1. **Use the transcription script** to get transcript text
2. **Copy the transcript**
3. **Paste into AIR agent** in LobeChat with:
   ```
   I have a YouTube transcript to archive. Here it is:
   
   [PASTE TRANSCRIPT]
   
   Title: [Video Title]
   URL: [YouTube URL]
   Source: [Channel Name]
   ```

4. **AIR processes it** and archives

### Option B: FastAPI Endpoint (Better)

Create a FastAPI endpoint that LobeChat can call:

**Create `youtube_api.py`:**
```python
from fastapi import FastAPI, HTTPException
from pydantic import BaseModel
from youtube_transcript_api import YouTubeTranscriptApi
from urllib.parse import urlparse, parse_qs

app = FastAPI()

class YouTubeRequest(BaseModel):
    url: str
    title: str = None
    channel: str = None

def extract_video_id(youtube_url):
    parsed_url = urlparse(youtube_url)
    if parsed_url.hostname == 'youtu.be':
        return parsed_url.path[1:]
    return parse_qs(parsed_url.query).get('v', [None])[0]

@app.post("/extract-transcript")
async def extract_transcript(request: YouTubeRequest):
    """Extract transcript from YouTube video"""
    try:
        video_id = extract_video_id(request.url)
        if not video_id:
            raise ValueError("Invalid YouTube URL")
        
        transcript_list = YouTubeTranscriptApi.get_transcript(video_id)
        full_transcript = " ".join([item['text'] for item in transcript_list])
        
        return {
            "status": "success",
            "video_id": video_id,
            "url": request.url,
            "title": request.title or "Unknown",
            "channel": request.channel or "Unknown",
            "transcript": full_transcript,
            "word_count": len(full_transcript.split()),
            "ready_for_air": True
        }
    except Exception as e:
        raise HTTPException(status_code=400, detail=str(e))

@app.post("/send-to-air")
async def send_to_air(request: YouTubeRequest):
    """Extract transcript and format for AIR"""
    result = await extract_transcript(request)
    
    if result["status"] == "success":
        # Format for AIR
        air_input = f"""
### YouTube Content Ready for AIR

**Video Title**: {result['title']}
**Channel**: {result['channel']}
**URL**: {result['url']}
**Word Count**: {result['word_count']}

### Full Transcript

{result['transcript']}

---

Please classify this knowledge, extract key information, and archive appropriately.
"""
        return {
            "formatted_for_air": air_input,
            "ready_to_paste": True
        }

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="localhost", port=8000)
```

**Run it:**
```bash
python youtube_api.py
# API will be available at http://localhost:8000
```

**Test the endpoint:**
```bash
curl -X POST http://localhost:8000/extract-transcript \
  -H "Content-Type: application/json" \
  -d '{
    "url": "https://www.youtube.com/watch?v=EXAMPLE",
    "title": "My Video Title",
    "channel": "My Channel"
  }'
```

---

## STEP 3: PREPARE AIR'S KNOWLEDGE BASE

### Create folder structure in LobeChat:

```
VBoarder_Knowledge_Base/
├── SOPs/
│   ├── Construction/
│   ├── Staging/
│   ├── Business_Operations/
│   ├── Technical_Infrastructure/
│   └── Decision_Making/
├── Policies/
├── Archives/
│   ├── Decisions/
│   ├── Meetings/
│   ├── Projects/
│   ├── Contracts/
│   └── Reference/
└── Context/
```

### Upload initial documents:
- Company context
- Existing SOPs
- Policies
- Past decisions (if you have them)

---

## STEP 4: WORKFLOW IN ACTION

### Example 1: Construction Technique Video

```
User: I found a great YouTube video about framing techniques
      Let me transcribe and send to you.

↓ [Transcription agent extracts content]

User (to AIR): I have a YouTube transcript to archive:

[TRANSCRIPT CONTENT]

Title: Advanced Framing Techniques
URL: https://youtube.com/watch?v=...
Channel: Construction Mastery

AIR Response:

### Summary
Video demonstrates advanced framing techniques including notching, 
bearing placement, and header sizing for various span requirements.

### Classification
- **Type**: SOP (Process Documentation)
- **Domain**: Construction
- **Urgency**: Important
- **Tags**: [framing, construction, techniques, video-source]

### Key Techniques Captured
- Header sizing calculator method
- Notching best practices
- Load calculation for bearing placement
- Common mistakes to avoid

### Archive Location
→ SOPs/Construction/Advanced_Framing_Techniques.md ✅

### Related Knowledge
→ Links to existing SOPs/Construction/ items
→ Connects to Archives/Reference/Building_Codes/

### Next Steps
✅ Ready for team use — searchable in knowledge base

```

### Example 2: Business Decision Video

```
User (to AIR): Business expert video about pricing strategies

[TRANSCRIPT]

AIR Response:

### Summary
Video covers pricing strategies for service-based businesses, 
including value-based pricing, competitive analysis, and market 
positioning.

### Classification
- **Type**: Reference Material
- **Domain**: Business/Pricing
- **Urgency**: Important
- **Tags**: [pricing, business-strategy, reference, video-source]

### Key Concepts
- Value-based pricing calculation
- Competitive analysis framework
- Market positioning strategy
- Price communication to customers

### Archive Location
→ Archives/Reference/Business_Pricing_Strategies.md ✅

### Recommendation
This pattern appears in pricing discussions. Recommend creating:
→ Policies/Pricing_Framework.md

### Next Steps
✅ Archived as reference material
→ CTO/Leadership: Review pricing framework recommendation
```

### Example 3: Meeting Video/Webinar

```
User (to AIR): Recorded webinar about new construction regulations

[TRANSCRIPT]

AIR Response:

### Summary
[Summary of webinar content]

### Classification
- **Type**: Reference Material (Industry Update)
- **Domain**: Construction/Compliance
- **Urgency**: Critical
- **Tags**: [regulations, compliance, construction, 2025]

### Key Regulatory Changes
- [Change 1]
- [Change 2]
- [Change 3]

### Archive Location
→ Archives/Reference/Construction_Regulations_2025.md ✅

### Delegations
→ **CTO**: Review and update SOPs/Construction/ if needed
→ **Secretary**: Alert compliance team to policy review

### Status
✅ Archived and flagged for review
⏳ Awaiting CTO confirmation on SOP updates
```

---

## STEP 5: REGULAR YOUTUBE INGESTION

### Weekly Workflow:

1. **Collect YouTube links** during the week
2. **Friday morning**: Run transcription on all links
3. **Friday afternoon**: Send batch to AIR
4. **AIR processes** and archives
5. **Team searches** and uses throughout next week

### Automated Option:

Create a simple checklist in your notes:
```
YOUTUBE INTAKE CHECKLIST
- [ ] Video 1: [URL] - [Topic]
- [ ] Video 2: [URL] - [Topic]
- [ ] Video 3: [URL] - [Topic]

When ready: Transcribe all → Send to AIR → Done
```

---

## STEP 6: SEARCHING THE KNOWLEDGE

Once archived, team members ask AIR:

```
User: Do we have anything about framing techniques?

AIR Response:
I found this in our knowledge base:

→ SOPs/Construction/Advanced_Framing_Techniques.md
   (From YouTube video, 2500 words, covers headers, notching, loads)

Would you like me to summarize specific sections?
```

---

## TOOLS NEEDED

### Minimum Setup:
- ✅ youtube-transcript-api (Python library)
- ✅ AIR agent in LobeChat
- ✅ VBoarder_Knowledge_Base in LobeChat
- ✅ 5 minutes per video to transcribe + send to AIR

### Better Setup:
- ✅ FastAPI endpoint for automation
- ✅ Scheduled transcription (weekly batch)
- ✅ AIR processes in batches
- ✅ Team searches knowledge base

### Advanced Setup:
- ✅ Automated YouTube feed monitoring
- ✅ Automatic transcription + archival
- ✅ Scheduled knowledge base maintenance
- ✅ Team notifications on new archives

---

## ESTIMATED TIME INVESTMENT

**Per video:**
- Transcription: 2-5 minutes (depends on length)
- AIR processing: 3-5 minutes
- **Total: 5-10 minutes per video**

**Weekly (3-5 videos):**
- Batch processing: 30-50 minutes
- **Or: Use FastAPI + schedule for automation**

---

## NEXT STEPS

1. **Create the transcription script** (step 1)
2. **Test on one YouTube video**
3. **Import AIR agent** into LobeChat
4. **Create knowledge base structure**
5. **Send first transcript to AIR**
6. **Verify it archives correctly**
7. **Scale to batch processing**

---

## QUESTIONS TO ASK AIR

Once set up, AIR can answer:

- "Do we have documentation on framing techniques?"
- "What construction processes do we have SOPs for?"
- "What decisions did we make about pricing?"
- "Summarize what we know about [topic]"
- "Are there any gaps in our knowledge about [area]?"
- "Compare our current approach to [past decision]"
- "What's the best practice for [task] based on our archives?"

---

## SUCCESS INDICATORS

✅ You've succeeded when:
- Team can find YouTube knowledge by searching
- New team members can learn from archived videos
- Construction expertise is documented and reusable
- Decisions are preserved with context
- Knowledge compounds over time
- You refer to "what we learned from that video" 6 months later

---

**Ready to build this? Start with Step 1 and let me know what questions come up.**
