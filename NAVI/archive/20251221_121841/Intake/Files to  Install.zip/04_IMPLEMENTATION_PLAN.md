# VBOARDER KNOWLEDGE BASE REORGANIZATION - IMPLEMENTATION PLAN
## Step-by-Step Instructions to Fix Everything

**Version:** 1.0  
**Created:** December 10, 2025  
**Purpose:** Complete roadmap to reorganize KB and memory system  
**Status:** Ready for implementation

---

## 📋 SUMMARY OF CHANGES

### Current State (MESSY)
```
D:\05_AGENTS\NAVI_RECEPTIONIST\memory\SOPs\
├─ NAVI_COMPLETE_SYSTEM_PROMPT.md
├─ NAVI_INTELLIGENT_SYSTEM_PROMPT.md
├─ NAVI_AUTOMATED_ROUTING_GUIDE.md
├─ NAVI_INTELLIGENT_INBOX_GUIDE.md
├─ 03_RECEPTIONIST_AGENT_PROMPT.md ❌ (not Navi's!)
├─ 04_AIR_AGENT_PROMPT.md ❌ (not Navi's!)
├─ 05_SECRETARY_AGENT_PROMPT.md ❌ (not Navi's!)
├─ 06_CTO_AGENT_PROMPT.md ❌ (not Navi's!)
├─ PHASE_ROLLOUT_CHECKLIST.md
└─ sample_sop.* (test files)

❌ PROBLEMS:
- 4 conflicting Navi prompts
- Other agents' prompts in Navi's folder
- No clear structure
- Duplication across files
- Confusion about what applies where
```

### Target State (CLEAN)
```
✅ SHARED_KNOWLEDGE_BASE\02_MAIL_ROOM\
├─ 01_SHARED_MAIL_ROOM_OPERATIONS.md
├─ 02_GTD_CLASSIFICATION.md
├─ 03_ROUTING_MATRIX.md
├─ 04_PRIORITY_LEVELS.md
└─ 05_PHASE_ROLLOUT_CHECKLIST.md

✅ NAVI_RECEPTIONIST\memory\SOPs\
├─ 01_NAVI_SYSTEM_PROMPT.md (THE ONE)
├─ 02_NAVI_QUICK_REFERENCE.md
├─ 03_NAVI_PROCEDURES.md
└─ 04_LINKS_TO_SHARED_STANDARDS.md

✅ RECEPTIONIST_AGENT\memory\SOPs\
├─ 01_RECEPTIONIST_SYSTEM_PROMPT.md
├─ 02_RECEPTIONIST_PROCEDURES.md
└─ 03_LINKS_TO_SHARED_STANDARDS.md

✅ AIR_AGENT\memory\SOPs\
├─ 01_AIR_SYSTEM_PROMPT.md
├─ 02_AIR_PROCEDURES.md
└─ 03_LINKS_TO_SHARED_STANDARDS.md

✅ SECRETARY_AGENT\memory\SOPs\
├─ 01_SECRETARY_SYSTEM_PROMPT.md
├─ 02_SECRETARY_PROCEDURES.md
└─ 03_LINKS_TO_SHARED_STANDARDS.md

✅ CTO_AGENT\memory\SOPs\
├─ 01_CTO_SYSTEM_PROMPT.md
├─ 02_CTO_PROCEDURES.md
└─ 03_LINKS_TO_SHARED_STANDARDS.md

✅ Clean, organized, no duplicates!
```

---

## 🚀 STEP-BY-STEP IMPLEMENTATION

### PHASE 1: CREATE SHARED KNOWLEDGE BASE

#### Step 1.1: Create Shared KB Folder Structure
```powershell
# Create folders if they don't exist
mkdir "D:\05_AGENTS\SHARED_KNOWLEDGE_BASE\02_MAIL_ROOM"
```

#### Step 1.2: Add Shared Standard Files
```
File 1: 01_SHARED_MAIL_ROOM_OPERATIONS.md
Source: Created above (01_SHARED_MAIL_ROOM_OPERATIONS.md)
Action: Copy to D:\05_AGENTS\SHARED_KNOWLEDGE_BASE\02_MAIL_ROOM\

File 2: 02_GTD_CLASSIFICATION.md
Action: Create (extract from existing docs or create new)

File 3: 03_ROUTING_MATRIX.md
Action: Create (extract from existing docs or create new)

File 4: 04_PRIORITY_LEVELS.md
Action: Create (extract from existing docs or create new)

File 5: 05_PHASE_ROLLOUT_CHECKLIST.md
Source: From your uploads
Action: Copy to D:\05_AGENTS\SHARED_KNOWLEDGE_BASE\02_MAIL_ROOM\
```

---

### PHASE 2: CLEAN UP NAVI'S MEMORY

#### Step 2.1: Delete Conflicting Prompts from Navi's Folder
```powershell
cd D:\05_AGENTS\NAVI_RECEPTIONIST\memory\SOPs\

# DELETE these files (they're being consolidated):
del NAVI_COMPLETE_SYSTEM_PROMPT.md
del NAVI_INTELLIGENT_SYSTEM_PROMPT.md
del NAVI_AUTOMATED_ROUTING_GUIDE.md
del NAVI_INTELLIGENT_INBOX_GUIDE.md

# DELETE these files (they're NOT Navi's):
del 03_RECEPTIONIST_AGENT_PROMPT.md
del 04_AIR_AGENT_PROMPT.md
del 05_SECRETARY_AGENT_PROMPT.md
del 06_CTO_AGENT_PROMPT.md

# DELETE test files:
del sample_sop.*
```

#### Step 2.2: Add Navi's Consolidated Files
```
File 1: 01_NAVI_SYSTEM_PROMPT.md
Source: Created above (02_NAVI_SYSTEM_PROMPT_CONSOLIDATED.md)
Action: Copy/rename to D:\05_AGENTS\NAVI_RECEPTIONIST\memory\SOPs\01_NAVI_SYSTEM_PROMPT.md

File 2: 02_NAVI_QUICK_REFERENCE.md
Action: Create (Navi's quick command reference)

File 3: 03_NAVI_PROCEDURES.md
Action: Create (Navi's daily/weekly procedures)

File 4: 04_LINKS_TO_SHARED_STANDARDS.md
Action: Create (links to shared KB)
```

#### Step 2.3: Move PHASE_ROLLOUT_CHECKLIST
```
File: PHASE_ROLLOUT_CHECKLIST.md (from Navi's current SOPs)
Action: KEEP in Navi's memory/SOPs/ OR move to SHARED_KB/02_MAIL_ROOM/
Decision: Keep in both (it's Navi-specific for phases, but also shared standard)
Location: D:\05_AGENTS\NAVI_RECEPTIONIST\memory\SOPs\05_PHASE_ROLLOUT_CHECKLIST.md
```

---

### PHASE 3: CREATE INDIVIDUAL AGENT FOLDERS & MOVE PROMPTS

#### Step 3.1: Create Receptionist Agent Folder
```powershell
mkdir "D:\05_AGENTS\RECEPTIONIST_AGENT\inbox"
mkdir "D:\05_AGENTS\RECEPTIONIST_AGENT\processing"
mkdir "D:\05_AGENTS\RECEPTIONIST_AGENT\archive"
mkdir "D:\05_AGENTS\RECEPTIONIST_AGENT\logs"
mkdir "D:\05_AGENTS\RECEPTIONIST_AGENT\outputs"
mkdir "D:\05_AGENTS\RECEPTIONIST_AGENT\memory\SOPs"
mkdir "D:\05_AGENTS\RECEPTIONIST_AGENT\memory\Context"
```

#### Step 3.2: Move Receptionist Prompt
```
File: 03_RECEPTIONIST_AGENT_PROMPT.md (from uploads)
Action: 
  1. Review and rename to: 01_RECEPTIONIST_SYSTEM_PROMPT.md
  2. Copy to: D:\05_AGENTS\RECEPTIONIST_AGENT\memory\SOPs\
  3. Update to reference shared standards
```

#### Step 3.3: Create Receptionist Procedures & Links
```
File: 02_RECEPTIONIST_PROCEDURES.md
Action: Create (receptionist-specific procedures)
Location: D:\05_AGENTS\RECEPTIONIST_AGENT\memory\SOPs\

File: 03_LINKS_TO_SHARED_STANDARDS.md
Action: Create (links to SHARED_KB)
Location: D:\05_AGENTS\RECEPTIONIST_AGENT\memory\SOPs\
```

#### Step 3.4: Repeat for AIR Agent
```
Create folder structure:
mkdir "D:\05_AGENTS\AIR_AGENT\..." (same as above)

Move prompt:
04_AIR_AGENT_PROMPT.md → 01_AIR_SYSTEM_PROMPT.md
Location: D:\05_AGENTS\AIR_AGENT\memory\SOPs\

Create procedures & links:
02_AIR_PROCEDURES.md
03_LINKS_TO_SHARED_STANDARDS.md
```

#### Step 3.5: Repeat for Secretary Agent
```
Create folder structure:
mkdir "D:\05_AGENTS\SECRETARY_AGENT\..." (same as above)

Move prompt:
05_SECRETARY_AGENT_PROMPT.md → 01_SECRETARY_SYSTEM_PROMPT.md
Location: D:\05_AGENTS\SECRETARY_AGENT\memory\SOPs\

Create procedures & links:
02_SECRETARY_PROCEDURES.md
03_LINKS_TO_SHARED_STANDARDS.md
```

#### Step 3.6: Repeat for CTO Agent
```
Create folder structure:
mkdir "D:\05_AGENTS\CTO_AGENT\..." (same as above)

Move prompt:
06_CTO_AGENT_PROMPT.md → 01_CTO_SYSTEM_PROMPT.md
Location: D:\05_AGENTS\CTO_AGENT\memory\SOPs\

Create procedures & links:
02_CTO_PROCEDURES.md
03_LINKS_TO_SHARED_STANDARDS.md
```

---

### PHASE 4: CREATE KB INDEX FILES

#### Step 4.1: Create Index for Each Agent
```json
File: kb_index.json

Location: D:\05_AGENTS\[AGENT_NAME]\memory\Context\

Content:
{
  "agent_name": "[Agent Name]",
  "knowledge_base": [
    {
      "file": "01_[AGENT]_SYSTEM_PROMPT.md",
      "category": "SOP",
      "priority": "CRITICAL",
      "description": "Core system prompt for this agent"
    },
    {
      "file": "02_[AGENT]_PROCEDURES.md",
      "category": "SOP",
      "priority": "HIGH",
      "description": "Agent-specific procedures"
    },
    {
      "file": "03_LINKS_TO_SHARED_STANDARDS.md",
      "category": "REFERENCE",
      "priority": "HIGH",
      "description": "Links to shared standards"
    }
  ],
  "shared_standards": {
    "location": "D:\\05_AGENTS\\SHARED_KNOWLEDGE_BASE\\02_MAIL_ROOM\\",
    "files": [
      "01_SHARED_MAIL_ROOM_OPERATIONS.md",
      "02_GTD_CLASSIFICATION.md",
      "03_ROUTING_MATRIX.md",
      "04_PRIORITY_LEVELS.md",
      "05_PHASE_ROLLOUT_CHECKLIST.md"
    ]
  }
}
```

---

## 📊 FINAL FOLDER STRUCTURE VERIFICATION

After all steps, verify:

```
✅ D:\05_AGENTS\SHARED_KNOWLEDGE_BASE\02_MAIL_ROOM\
   ├─ 01_SHARED_MAIL_ROOM_OPERATIONS.md
   ├─ 02_GTD_CLASSIFICATION.md
   ├─ 03_ROUTING_MATRIX.md
   ├─ 04_PRIORITY_LEVELS.md
   └─ 05_PHASE_ROLLOUT_CHECKLIST.md

✅ D:\05_AGENTS\NAVI_RECEPTIONIST\memory\SOPs\
   ├─ 01_NAVI_SYSTEM_PROMPT.md
   ├─ 02_NAVI_QUICK_REFERENCE.md
   ├─ 03_NAVI_PROCEDURES.md
   ├─ 04_LINKS_TO_SHARED_STANDARDS.md
   └─ 05_PHASE_ROLLOUT_CHECKLIST.md

✅ D:\05_AGENTS\RECEPTIONIST_AGENT\memory\SOPs\
   ├─ 01_RECEPTIONIST_SYSTEM_PROMPT.md
   ├─ 02_RECEPTIONIST_PROCEDURES.md
   └─ 03_LINKS_TO_SHARED_STANDARDS.md

✅ D:\05_AGENTS\AIR_AGENT\memory\SOPs\
   ├─ 01_AIR_SYSTEM_PROMPT.md
   ├─ 02_AIR_PROCEDURES.md
   └─ 03_LINKS_TO_SHARED_STANDARDS.md

✅ D:\05_AGENTS\SECRETARY_AGENT\memory\SOPs\
   ├─ 01_SECRETARY_SYSTEM_PROMPT.md
   ├─ 02_SECRETARY_PROCEDURES.md
   └─ 03_LINKS_TO_SHARED_STANDARDS.md

✅ D:\05_AGENTS\CTO_AGENT\memory\SOPs\
   ├─ 01_CTO_SYSTEM_PROMPT.md
   ├─ 02_CTO_PROCEDURES.md
   └─ 03_LINKS_TO_SHARED_STANDARDS.md
```

---

## ✅ COMPLETION CHECKLIST

Use this to track progress:

```
PHASE 1: CREATE SHARED KNOWLEDGE BASE
☐ Create SHARED_KNOWLEDGE_BASE\02_MAIL_ROOM\ folder
☐ Copy 01_SHARED_MAIL_ROOM_OPERATIONS.md
☐ Create 02_GTD_CLASSIFICATION.md
☐ Create 03_ROUTING_MATRIX.md
☐ Create 04_PRIORITY_LEVELS.md
☐ Copy 05_PHASE_ROLLOUT_CHECKLIST.md

PHASE 2: CLEAN UP NAVI'S MEMORY
☐ Delete NAVI_COMPLETE_SYSTEM_PROMPT.md
☐ Delete NAVI_INTELLIGENT_SYSTEM_PROMPT.md
☐ Delete NAVI_AUTOMATED_ROUTING_GUIDE.md
☐ Delete NAVI_INTELLIGENT_INBOX_GUIDE.md
☐ Delete 03_RECEPTIONIST_AGENT_PROMPT.md
☐ Delete 04_AIR_AGENT_PROMPT.md
☐ Delete 05_SECRETARY_AGENT_PROMPT.md
☐ Delete 06_CTO_AGENT_PROMPT.md
☐ Delete sample_sop.* files
☐ Copy 01_NAVI_SYSTEM_PROMPT.md (consolidated)
☐ Create 02_NAVI_QUICK_REFERENCE.md
☐ Create 03_NAVI_PROCEDURES.md
☐ Create 04_LINKS_TO_SHARED_STANDARDS.md

PHASE 3: CREATE AGENT FOLDERS
☐ RECEPTIONIST_AGENT folder & structure
☐ Move 03_RECEPTIONIST_AGENT_PROMPT.md
☐ Create receptionist procedures & links
☐ AIR_AGENT folder & structure
☐ Move 04_AIR_AGENT_PROMPT.md
☐ Create AIR procedures & links
☐ SECRETARY_AGENT folder & structure
☐ Move 05_SECRETARY_AGENT_PROMPT.md
☐ Create secretary procedures & links
☐ CTO_AGENT folder & structure
☐ Move 06_CTO_AGENT_PROMPT.md
☐ Create CTO procedures & links

PHASE 4: CREATE KB INDEXES
☐ Create kb_index.json for RECEPTIONIST_AGENT
☐ Create kb_index.json for AIR_AGENT
☐ Create kb_index.json for SECRETARY_AGENT
☐ Create kb_index.json for CTO_AGENT
☐ Create kb_index.json for NAVI_RECEPTIONIST

FINAL VERIFICATION
☐ Navi has exactly ONE system prompt
☐ Each agent has exactly ONE system prompt
☐ No duplicate agent prompts
☐ All agents link to shared standards
☐ Shared standards exist in one place
☐ No orphaned files
☐ All folder structures match template
```

---

## 📊 FILES CREATED FOR YOU

The following files have been created and are ready to use:

```
✅ 01_SHARED_MAIL_ROOM_OPERATIONS.md
   (Shared standard for all agents)

✅ 02_NAVI_SYSTEM_PROMPT_CONSOLIDATED.md
   (Navi's consolidated, single prompt)

✅ 03_KB_ORGANIZATION_GUIDE.md
   (Complete organization structure)

✅ 04_IMPLEMENTATION_PLAN.md
   (This file - step-by-step instructions)
```

**All files are in:** `/mnt/user-data/outputs/`

---

## 🚀 NEXT STEPS

1. **Review the 4 files above**
2. **Follow the implementation steps in order**
3. **Check off items in completion checklist**
4. **Verify final folder structure**
5. **Delete old conflicting files**
6. **Confirm KB is clean and organized**

---

**You're ready to implement! This will fix everything and make the system clean, organized, and scalable.** ✨

