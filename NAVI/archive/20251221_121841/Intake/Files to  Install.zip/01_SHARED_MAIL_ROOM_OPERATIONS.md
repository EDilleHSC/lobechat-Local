# SHARED KNOWLEDGE BASE: CORE MAIL ROOM OPERATIONS
## Standard Operating Procedures for All Agents

**Location:** `D:\05_AGENTS\SHARED_KNOWLEDGE_BASE\02_MAIL_ROOM\`  
**Purpose:** Standardized procedures used by ALL agents in VBoarder system  
**Version:** 1.0  
**Last Updated:** December 10, 2025

---

## 🎯 CORE MISSION

Every file that enters the VBoarder system follows the same intake, classification, and routing process:

```
FILE ARRIVES → INTELLIGENCE EXTRACTION → GTD CLASSIFICATION → SMART ROUTING → AGENT INBOX
```

This document defines that standard process.

---

## 📥 INTAKE PROCESS

### File Reception
- Files arrive in agent inbox (external or internal source)
- Watchdog detects file automatically
- File metadata captured (name, size, date, type)
- File available for processing

### Intelligence Extraction
Extract key information from every file:
```
✅ Entities:
   ├─ Email addresses
   ├─ Phone numbers
   ├─ Names/contacts
   ├─ Dates/deadlines
   └─ Amounts ($)

✅ Content Analysis:
   ├─ File type classification
   ├─ Priority indicators
   ├─ Action keywords
   ├─ Urgency signals
   └─ Subject matter

✅ Metadata:
   ├─ File size
   ├─ Creation/modification date
   ├─ File format
   └─ Processing timestamp
```

---

## 📋 GTD CLASSIFICATION STANDARD

Every file gets classified into ONE of these categories:

### **@NextAction** (Immediate action required)
**Definition:** File requires immediate physical action
**Characteristics:**
- URGENT priority
- Specific action items
- Time-sensitive
- Decision needed
- Deadline today/tomorrow

**Examples:**
- System errors requiring immediate fix
- Urgent invoices requiring approval
- Critical security issues
- Emergency requests

**Navi Routes To:** CTO, CFO, CEO (depends on content)

---

### **@Project** (Multi-step coordination)
**Definition:** File is part of larger project/initiative
**Characteristics:**
- Requires multiple steps
- Team coordination needed
- Progress tracking
- Multiple dependencies
- Timeline > 1 day

**Examples:**
- Implementation rollouts
- Project proposals
- Initiative planning
- Phased implementations

**Navi Routes To:** Project owner, Secretary for coordination

---

### **@Waiting** (Awaiting external response)
**Definition:** File is blocked waiting for something
**Characteristics:**
- Pending approval
- Waiting for response
- External dependency
- No action possible now
- Follow-up required

**Examples:**
- Vendor quotes awaiting response
- Approval pending from stakeholder
- Information request pending
- Waiting for decision

**Navi Routes To:** Secretary for follow-up tracking

---

### **@Reference** (Archive for future use)
**Definition:** Information for future reference
**Characteristics:**
- No immediate action
- Documentation
- Policy guides
- Historical records
- Background information

**Examples:**
- Policy documents
- Technical documentation
- Reference materials
- Guidelines

**Navi Routes To:** AIR (Archives/Information/Research)

---

### **@Someday** (Future consideration)
**Definition:** Nice-to-have, not urgent
**Characteristics:**
- Low priority
- Future consideration
- Backlog items
- Strategic initiatives
- Can wait indefinitely

**Examples:**
- Improvement suggestions
- Future projects
- Long-term initiatives
- Nice-to-have enhancements

**Navi Routes To:** Archive or backlog folder

---

## 🎯 ROUTING MATRIX STANDARD

Based on file content, route to appropriate agent/department:

| Content Type | Primary Indicators | Route To | Priority |
|--------------|-------------------|----------|----------|
| **Technical/System** | Server, error, CPU, network, infrastructure, system | CTO | Check urgency |
| **Security** | Breach, vulnerability, access, credentials, security alert | CSO | IMMEDIATE |
| **Legal/Contract** | Contract, legal, compliance, agreement, lawsuit, regulation | LEGAL | Check deadline |
| **Financial** | Invoice, payment, budget, PO, financial, costs, amount | CFO | Check urgency |
| **Marketing/Brand** | Marketing, campaign, brand, content, communications, social | CMO | Standard |
| **Operations** | Process, workflow, procedure, operations, improvement | COO | Standard |
| **Executive** | Strategic, executive decision, CEO approval, board | CEO | Check urgency |
| **Coordination** | Meeting, scheduling, task, follow-up, coordination | Secretary | Standard |
| **General Info** | Archive, document, policy, reference, historical | AIR | Low priority |

---

## ⚡ PRIORITY LEVEL STANDARD

Every file gets a priority score (0-10):

### **URGENT (9-10)**
- Immediate action required
- Deadline today/tomorrow
- Critical errors
- Security issues
- Requires executive approval
- Time-sensitive

**Action:** Process immediately, escalate if needed

### **HIGH (6-8)**
- Important business decision
- Deadline this week
- Stakeholder approval needed
- Significant impact
- Resource commitment

**Action:** Process today, route to responsible agent

### **MEDIUM (3-5)**
- Standard processing
- Deadline this month
- Routine business items
- No urgent deadlines
- Regular workflow

**Action:** Process in normal sequence

### **LOW (0-2)**
- Archive/reference
- No deadline
- Future consideration
- Background information
- Nice-to-have

**Action:** Archive or defer to backlog

---

## 🔄 PROCESSING WORKFLOW STANDARD

All files follow this standardized workflow:

```
STEP 1: FILE DETECTION
├─ Watchdog detects new file
├─ File metadata captured
└─ Status: NEW

STEP 2: INTELLIGENCE EXTRACTION
├─ Entities extracted (contacts, dates, amounts)
├─ Content analyzed
├─ Priority scored
└─ Status: ANALYZED

STEP 3: GTD CLASSIFICATION
├─ Classified into @NextAction/@Project/@Waiting/@Reference/@Someday
├─ Context determined
├─ Agent assignment prepared
└─ Status: CLASSIFIED

STEP 4: SMART ROUTING
├─ Route determined based on content
├─ Agent selected
├─ Escalation path identified
└─ Status: ROUTED

STEP 5: MOVE TO AGENT INBOX
├─ File moved to agent's inbox folder
├─ Status updated in tracking
├─ Agent notified of new work
└─ Status: IN_QUEUE

STEP 6: TRACKING
├─ File tracked until completion
├─ Status updates logged
├─ Completion confirmed
└─ File moved to archive
```

---

## 📊 STATUS TRACKING STANDARD

All files have tracked status throughout lifecycle:

### **Status Values**
```
NEW           → Just arrived
ANALYZING     → Intelligence extraction in progress
CLASSIFIED    → GTD classification complete
ROUTED        → Agent assignment ready
IN_QUEUE      → In agent's inbox waiting
IN_PROGRESS   → Agent working on it
BLOCKED       → Waiting for something
COMPLETED     → Task complete
ARCHIVED      → File moved to archive
```

### **Tracking Information**
For each file, maintain:
- Current status
- Assigned agent
- Priority level
- GTD classification
- Key entities (contacts, amounts, dates)
- Last update timestamp
- Expected completion date

---

## 🎓 AGENT RESPONSIBILITIES STANDARD

Every agent using this system has standard responsibilities:

### **INTAKE (First agent receiving file)**
- ✅ Verify file received
- ✅ Check for missing information
- ✅ Route to correct next agent if needed

### **PROCESSING**
- ✅ Use intelligence provided by system
- ✅ Follow GTD classification for context
- ✅ Complete assigned task
- ✅ Document progress
- ✅ Flag blockers immediately

### **OUTPUT**
- ✅ Deliver expected result
- ✅ Update status
- ✅ Move to archive
- ✅ Provide completion confirmation

### **ESCALATION**
- ✅ Escalate if blocked > 24 hours
- ✅ Escalate if exceeds authority
- ✅ Escalate if new critical issues discovered
- ✅ Follow escalation path (defined per agent type)

---

## 🚨 URGENT HANDLING STANDARD

All urgent files follow special protocol:

```
DETECTION:
├─ Watchdog flags as URGENT (priority 9-10)
└─ Agent receives urgent notification

IMMEDIATE ACTION:
├─ Route to appropriate agent IMMEDIATELY
├─ Mark as top priority
├─ Notify agent of urgency
└─ Request immediate response

TRACKING:
├─ Monitor closely
├─ Escalate if stuck > 1 hour
├─ Provide status updates
└─ Don't let urgent items slip

NEVER:
❌ Leave urgent item in queue
❌ Defer urgent processing
❌ Lose track of urgent items
❌ Process lower priority first if urgent pending
```

---

## 📈 PERFORMANCE STANDARDS

All agents must meet these standards:

| Metric | Target | Measurement |
|--------|--------|-------------|
| **Processing Accuracy** | 95%+ | Errors per 100 files |
| **Urgent Response** | < 1 hour | Time to process urgent item |
| **Standard Processing** | < 24 hours | Time to complete standard task |
| **Status Updates** | Real-time | When status changes |
| **Escalation** | Immediate | When blocking occurs |
| **Archive** | 30 days | Files older than 30 days |

---

## 🔧 TOOLS AVAILABLE TO ALL AGENTS

Standard tools available in all agent systems:

```
✅ Intelligence Database Access
   └─ Can query file intelligence (entities, priorities, etc.)

✅ Status Tracking
   └─ Can update file status
   └─ Can monitor file progress

✅ Escalation System
   └─ Can escalate to higher authority
   └─ Can request help from other agents

✅ Archive System
   └─ Can move files to archive
   └─ Can retrieve archived files

✅ Notification System
   └─ Can notify other agents
   └─ Can send status updates
```

---

## 📋 CONTINUOUS IMPROVEMENT

All agents contribute to system improvement:

### **Report Issues**
- Found a problem with classification? Report it
- Noticed a processing bottleneck? Flag it
- Have improvement idea? Suggest it

### **Learning**
- System learns from corrections
- Improves routing over time
- Optimizes processing workflows

### **Documentation**
- Keep procedures up to date
- Document special cases
- Share knowledge with other agents

---

## 📞 QUESTIONS & ESCALATION

If unclear on any standard:

1. **Check this document** first
2. **Ask your agent supervisor** (if applicable)
3. **Escalate to CTO** for technical questions
4. **Escalate to CEO** for policy questions

---

**These standards apply to ALL agents in the VBoarder system.**

Questions? Reference this document and your agent-specific SOP.

