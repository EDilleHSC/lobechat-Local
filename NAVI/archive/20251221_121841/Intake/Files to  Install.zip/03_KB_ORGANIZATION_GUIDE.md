# VBOARDER KNOWLEDGE BASE & MEMORY ORGANIZATION
## Complete Folder Structure and Organization Guide

**Version:** 1.0  
**Updated:** December 10, 2025  
**Purpose:** Define correct folder structure for all agents and shared knowledge

---

## 🗂️ COMPLETE FOLDER STRUCTURE

```
D:\
└─ 05_AGENTS\
   │
   ├─ SHARED_KNOWLEDGE_BASE\
   │  └─ 02_MAIL_ROOM\
   │     ├─ 01_SHARED_MAIL_ROOM_OPERATIONS.md ⭐ STANDARD
   │     ├─ 02_GTD_CLASSIFICATION.md (reference)
   │     ├─ 03_ROUTING_MATRIX.md (reference)
   │     ├─ 04_PRIORITY_LEVELS.md (reference)
   │     └─ 05_PHASE_ROLLOUT_CHECKLIST.md
   │
   ├─ NAVI_RECEPTIONIST\
   │  ├─ inbox\                    (incoming files)
   │  ├─ processing\               (files being worked)
   │  ├─ archive\                  (completed files)
   │  ├─ intelligence\             (navi_intelligence.json)
   │  ├─ logs\                     (activity logs)
   │  ├─ outputs\                  (reports/extracts)
   │  │
   │  └─ memory\
   │     │
   │     ├─ SOPs\
   │     │  ├─ 01_NAVI_SYSTEM_PROMPT.md ⭐ HER PROMPT (THE ONE)
   │     │  ├─ 02_NAVI_QUICK_REFERENCE.md
   │     │  ├─ 03_NAVI_PROCEDURES.md
   │     │  └─ 04_LINKS_TO_SHARED_STANDARDS.md
   │     │
   │     └─ Context\
   │        ├─ CURRENT_STATUS.md
   │        ├─ MAIL_ROOM_STATE.md
   │        └─ kb_index.json
   │
   │
   ├─ RECEPTIONIST_AGENT\
   │  ├─ inbox\
   │  ├─ processing\
   │  ├─ archive\
   │  ├─ logs\
   │  ├─ outputs\
   │  │
   │  └─ memory\
   │     ├─ SOPs\
   │     │  ├─ 01_RECEPTIONIST_SYSTEM_PROMPT.md ⭐ THEIR PROMPT
   │     │  ├─ 02_RECEPTIONIST_PROCEDURES.md
   │     │  └─ 03_LINKS_TO_SHARED_STANDARDS.md
   │     │
   │     └─ Context\
   │        └─ kb_index.json
   │
   │
   ├─ AIR_AGENT\
   │  ├─ inbox\
   │  ├─ processing\
   │  ├─ archive\
   │  ├─ logs\
   │  ├─ outputs\
   │  │
   │  └─ memory\
   │     ├─ SOPs\
   │     │  ├─ 01_AIR_SYSTEM_PROMPT.md ⭐ THEIR PROMPT
   │     │  ├─ 02_AIR_PROCEDURES.md
   │     │  └─ 03_LINKS_TO_SHARED_STANDARDS.md
   │     │
   │     └─ Context\
   │        └─ kb_index.json
   │
   │
   ├─ SECRETARY_AGENT\
   │  ├─ inbox\
   │  ├─ processing\
   │  ├─ archive\
   │  ├─ logs\
   │  ├─ outputs\
   │  │
   │  └─ memory\
   │     ├─ SOPs\
   │     │  ├─ 01_SECRETARY_SYSTEM_PROMPT.md ⭐ THEIR PROMPT
   │     │  ├─ 02_SECRETARY_PROCEDURES.md
   │     │  └─ 03_LINKS_TO_SHARED_STANDARDS.md
   │     │
   │     └─ Context\
   │        └─ kb_index.json
   │
   │
   ├─ CTO_AGENT\
   │  ├─ inbox\
   │  ├─ processing\
   │  ├─ archive\
   │  ├─ logs\
   │  ├─ outputs\
   │  │
   │  └─ memory\
   │     ├─ SOPs\
   │     │  ├─ 01_CTO_SYSTEM_PROMPT.md ⭐ THEIR PROMPT
   │     │  ├─ 02_CTO_PROCEDURES.md
   │     │  └─ 03_LINKS_TO_SHARED_STANDARDS.md
   │     │
   │     └─ Context\
   │        └─ kb_index.json
   │
   │
   └─ [OTHER AGENTS]
      └─ [Same structure as above]
```

---

## ✅ KEY PRINCIPLES

### 1. **SHARED STANDARDS** (Used by ALL agents)
```
Location: D:\05_AGENTS\SHARED_KNOWLEDGE_BASE\02_MAIL_ROOM\

Files:
✅ 01_SHARED_MAIL_ROOM_OPERATIONS.md (THE standard)
✅ 02_GTD_CLASSIFICATION.md
✅ 03_ROUTING_MATRIX.md
✅ 04_PRIORITY_LEVELS.md
✅ 05_PHASE_ROLLOUT_CHECKLIST.md

Purpose:
Every agent references these for standard procedures.
They are NOT duplicated in agent folders.
They are LINKED from agent folders.
```

### 2. **AGENT-SPECIFIC PROMPTS** (ONE per agent)
```
Location: D:\05_AGENTS\[AGENT_NAME]\memory\SOPs\01_[AGENT]_SYSTEM_PROMPT.md

Rules:
✅ ONE prompt file per agent (not 4 different versions!)
✅ Located in THEIR OWN folder (not in other agent's folder)
✅ References shared standards (doesn't duplicate them)
✅ Contains agent-specific procedures (not other agents' stuff)
✅ Is their source of truth for operations
```

### 3. **NAVI IS SPECIAL** (Different from other agents)
```
Navi's Role:
✅ Receptionist/mail room (initial intake)
✅ Receives files from outside
✅ Routes to other agents
✅ Has intelligence access to ALL files
✅ Is the central coordinator

Navi's Memory:
✅ 01_NAVI_SYSTEM_PROMPT.md (THE one prompt)
✅ References shared standards
✅ Has access to navi_intelligence.json
✅ Coordinates with other agents
```

---

## 🗑️ WHAT TO DELETE

From Navi's memory (REMOVE THESE):

```
❌ NAVI_COMPLETE_SYSTEM_PROMPT.md
   → Consolidated into 01_NAVI_SYSTEM_PROMPT.md

❌ NAVI_INTELLIGENT_SYSTEM_PROMPT.md
   → Consolidated into 01_NAVI_SYSTEM_PROMPT.md

❌ NAVI_AUTOMATED_ROUTING_GUIDE.md
   → Content moved to shared standards

❌ NAVI_INTELLIGENT_INBOX_GUIDE.md
   → Content moved to 01_NAVI_SYSTEM_PROMPT.md

❌ 03_RECEPTIONIST_AGENT_PROMPT.md
   → Move to D:\05_AGENTS\RECEPTIONIST_AGENT\memory\SOPs\

❌ 04_AIR_AGENT_PROMPT.md
   → Move to D:\05_AGENTS\AIR_AGENT\memory\SOPs\

❌ 05_SECRETARY_AGENT_PROMPT.md
   → Move to D:\05_AGENTS\SECRETARY_AGENT\memory\SOPs\

❌ 06_CTO_AGENT_PROMPT.md
   → Move to D:\05_AGENTS\CTO_AGENT\memory\SOPs\

❌ sample_sop.txt & sample_sop_metadata.json
   → These are just samples, delete or archive
```

---

## 📝 WHAT TO CREATE

### Create Shared Standards
```
D:\05_AGENTS\SHARED_KNOWLEDGE_BASE\02_MAIL_ROOM\

Files to create:
✅ 01_SHARED_MAIL_ROOM_OPERATIONS.md (DONE - created above)
✅ 02_GTD_CLASSIFICATION.md (reference or link)
✅ 03_ROUTING_MATRIX.md (reference or link)
✅ 04_PRIORITY_LEVELS.md (reference or link)
✅ 05_PHASE_ROLLOUT_CHECKLIST.md (from uploads)

Purpose: Single source of truth for ALL agents
```

### Create/Move Agent Folders
```
FOR EACH AGENT (Receptionist, AIR, Secretary, CTO):

Create:
✅ D:\05_AGENTS\[AGENT_NAME]\memory\SOPs\01_[AGENT]_SYSTEM_PROMPT.md
   (Move their prompt here, named properly)

✅ D:\05_AGENTS\[AGENT_NAME]\memory\SOPs\02_[AGENT]_PROCEDURES.md
   (Agent-specific procedures)

✅ D:\05_AGENTS\[AGENT_NAME]\memory\SOPs\03_LINKS_TO_SHARED_STANDARDS.md
   (Links to shared KB with guidance)

✅ D:\05_AGENTS\[AGENT_NAME]\memory\Context\kb_index.json
   (Index of their KB)
```

### Navi-Specific Files
```
D:\05_AGENTS\NAVI_RECEPTIONIST\memory\SOPs\

Keep/Create:
✅ 01_NAVI_SYSTEM_PROMPT.md (DONE - consolidated above)
✅ 02_NAVI_QUICK_REFERENCE.md (quick commands)
✅ 03_NAVI_PROCEDURES.md (daily operations)
✅ 04_LINKS_TO_SHARED_STANDARDS.md (reference guide)

D:\05_AGENTS\NAVI_RECEPTIONIST\memory\Context\
✅ CURRENT_STATUS.md (live status)
✅ kb_index.json (index)
```

---

## 🔗 LINKING TO SHARED STANDARDS

Each agent should have a "Links to Shared Standards" file:

```markdown
# Links to Shared Standards

This agent uses shared standards from:
D:\05_AGENTS\SHARED_KNOWLEDGE_BASE\02_MAIL_ROOM\

**Core Standards:**
- See: 01_SHARED_MAIL_ROOM_OPERATIONS.md
  (Workflow, GTD, Routing, Priority levels)

**GTD Methodology:**
- See: 02_GTD_CLASSIFICATION.md

**Routing Rules:**
- See: 03_ROUTING_MATRIX.md

**Priority Levels:**
- See: 04_PRIORITY_LEVELS.md

**Phase Rollout:**
- See: 05_PHASE_ROLLOUT_CHECKLIST.md

All agents follow these standards.
This file is your reference guide to them.
```

---

## 📊 FILE COUNT BY AGENT

### Navi's Memory
```
SOPs/ folder:
├─ 01_NAVI_SYSTEM_PROMPT.md
├─ 02_NAVI_QUICK_REFERENCE.md
├─ 03_NAVI_PROCEDURES.md
└─ 04_LINKS_TO_SHARED_STANDARDS.md

Context/ folder:
├─ CURRENT_STATUS.md
└─ kb_index.json

Total: 6 files (clean, organized, no duplicates)
```

### Other Agents (Receptionist, AIR, Secretary, CTO)
```
SOPs/ folder:
├─ 01_[AGENT]_SYSTEM_PROMPT.md
├─ 02_[AGENT]_PROCEDURES.md
└─ 03_LINKS_TO_SHARED_STANDARDS.md

Context/ folder:
└─ kb_index.json

Total per agent: 4 files (clean, focused)
```

### Shared Knowledge Base
```
02_MAIL_ROOM/ folder:
├─ 01_SHARED_MAIL_ROOM_OPERATIONS.md
├─ 02_GTD_CLASSIFICATION.md
├─ 03_ROUTING_MATRIX.md
├─ 04_PRIORITY_LEVELS.md
└─ 05_PHASE_ROLLOUT_CHECKLIST.md

Total: 5 files (used by ALL agents, never duplicated)
```

---

## 🎯 IMPLEMENTATION STEPS

### Step 1: Create Shared Knowledge Base ✅ (DONE above)
```
✅ 01_SHARED_MAIL_ROOM_OPERATIONS.md created
⏳ Move to: D:\05_AGENTS\SHARED_KNOWLEDGE_BASE\02_MAIL_ROOM\
```

### Step 2: Create Navi's Consolidated Prompt ✅ (DONE above)
```
✅ 02_NAVI_SYSTEM_PROMPT_CONSOLIDATED.md created
⏳ Move to: D:\05_AGENTS\NAVI_RECEPTIONIST\memory\SOPs\01_NAVI_SYSTEM_PROMPT.md
```

### Step 3: Create Individual Agent Folders ⏳ (NEXT)
```
For each agent (Receptionist, AIR, Secretary, CTO):
⏳ Create folder structure
⏳ Move their prompts
⏳ Create procedures file
⏳ Create links file
```

### Step 4: Delete Duplicates ⏳ (NEXT)
```
⏳ Delete old conflicting prompts from Navi's folder
⏳ Delete sample files
⏳ Clean up any orphaned files
```

### Step 5: Create Links Files ⏳ (NEXT)
```
⏳ Each agent gets 03_LINKS_TO_SHARED_STANDARDS.md
⏳ Points to shared KB
⏳ Explains what standards apply to them
```

---

## 🔍 VERIFICATION CHECKLIST

After implementation:

```
✅ Shared Knowledge Base exists
   └─ D:\05_AGENTS\SHARED_KNOWLEDGE_BASE\02_MAIL_ROOM\

✅ Navi has ONE system prompt
   └─ D:\05_AGENTS\NAVI_RECEPTIONIST\memory\SOPs\01_NAVI_SYSTEM_PROMPT.md
   └─ No other conflicting prompts

✅ Each agent has their own folder
   └─ RECEPTIONIST_AGENT\ with their prompts
   └─ AIR_AGENT\ with their prompts
   └─ SECRETARY_AGENT\ with their prompts
   └─ CTO_AGENT\ with their prompts

✅ No duplicate agent prompts
   └─ Receptionist prompt only in RECEPTIONIST_AGENT folder
   └─ AIR prompt only in AIR_AGENT folder
   └─ etc.

✅ Every agent links to shared standards
   └─ Has 03_LINKS_TO_SHARED_STANDARDS.md
   └─ References D:\05_AGENTS\SHARED_KNOWLEDGE_BASE\

✅ No orphaned files
   └─ Old prompts deleted
   └─ Sample files cleaned up
   └─ Structure is clean and organized
```

---

## 📚 REFERENCES

**Shared Standards Location:**
```
D:\05_AGENTS\SHARED_KNOWLEDGE_BASE\02_MAIL_ROOM\01_SHARED_MAIL_ROOM_OPERATIONS.md
```

**Navi's Prompt Location:**
```
D:\05_AGENTS\NAVI_RECEPTIONIST\memory\SOPs\01_NAVI_SYSTEM_PROMPT.md
```

**Agent Prompt Location Template:**
```
D:\05_AGENTS\[AGENT_NAME]\memory\SOPs\01_[AGENT]_SYSTEM_PROMPT.md
```

---

**This structure is CLEAN, ORGANIZED, and SCALABLE.**

When you add new agents in the future:
1. Create their folder: `D:\05_AGENTS\[NEW_AGENT]\`
2. Use standard subfolder structure
3. Create their system prompt
4. Link to shared standards

That's it! 🚀

