# SCHOOLHOUSE EXTRACTION PLAN
## Move Agents from Schoolhouse to 05_AGENTS Ecosystem

**Version:** 1.0  
**Created:** December 10, 2025  
**Purpose:** Extract all schoolhouse agents and integrate into 05_AGENTS structure

---

## 🎯 THE MISSION

**Current State:**
- 25GB of educational/training content in schoolhouse folder
- Contains agent templates we haven't worked with
- All marked as NON-PRODUCTION

**Target State:**
- Extract ALL usable agents → 05_AGENTS/02_WORKSHOP
- Archive schoolhouse educational materials
- Create templates for future development
- Clean up 04_PROJECTS

---

## 📊 WHAT WE KNOW

**From our previous analysis:**

```
Schoolhouse folder contains:
├─ Agent templates (various types)
├─ Training materials
├─ Educational content
└─ Documentation

Status: NOT USED RECENTLY
All agents: NON-PRODUCTION (never deployed)
Size: 25GB total
Action: Extract agents, archive rest
```

---

## 🔍 EXTRACTION PROCESS

### **Step 1: Identify All Agents**

Task: List all agents in schoolhouse folder

```powershell
Get-ChildItem "D:\04_PROJECTS\schoolhouse\" -Filter "*agent*" -Recurse -Directory
```

**Expected Result:**
```
[List of agent folders/files]
├─ [Agent 1]
├─ [Agent 2]
├─ [Agent 3]
└─ [etc...]
```

---

### **Step 2: Extract Agent Prompt Files**

For each agent identified:

1. Find system prompt file (usually named something like):
   - `system_prompt.md`
   - `[AGENT_NAME]_prompt.md`
   - `01_[AGENT_NAME]_SYSTEM_PROMPT.md`
   - etc.

2. Extract to staging area for review

---

### **Step 3: Create Agent Templates in 05_AGENTS**

For each extracted agent:

```
Target Location: D:\05_AGENTS\02_WORKSHOP\[AGENT_NAME]\

Create Structure:
├─ inbox/
├─ processing/
├─ archive/
├─ logs/
├─ outputs/
└─ memory/
   ├─ SOPs/
   │  ├─ 01_[AGENT]_SYSTEM_PROMPT.md
   │  ├─ 02_[AGENT]_PROCEDURES.md
   │  ├─ 03_LINKS_TO_SHARED_STANDARDS.md
   │  └─ kb_index.json
   └─ Context/
```

---

### **Step 4: Categorize Agents**

**Agents to Extract:**
```
Copy to: D:\05_AGENTS\02_WORKSHOP\[AGENT_NAME]\
Status: TEMPLATE (not yet developed)
Purpose: Ready for future development
```

**Educational Content to Archive:**
```
Move to: D:\04_PROJECTS\ARCHIVE\Schoolhouse\docs\
Status: Reference material
Purpose: Training/learning (can review later)
```

---

## 📋 EXPECTED AGENTS (ESTIMATED)

Based on previous context, schoolhouse may contain:

| Agent | Type | Purpose | Action |
|-------|------|---------|--------|
| [Agent 1] | ? | ? | Extract |
| [Agent 2] | ? | ? | Extract |
| [Agent 3] | ? | ? | Extract |
| [Etc.] | ? | ? | Extract |

**Note:** Actual list depends on what's in schoolhouse folder

---

## 🔄 EXTRACTION WORKFLOW

```
FOR EACH AGENT IN SCHOOLHOUSE:

1. Locate agent prompt file
   └─ Find [AGENT]_prompt.md or equivalent

2. Copy agent to 05_AGENTS/02_WORKSHOP/
   └─ Create folder structure

3. Rename prompt file
   └─ 01_[AGENT]_SYSTEM_PROMPT.md

4. Create supporting files
   └─ 02_PROCEDURES.md
   └─ 03_LINKS_TO_SHARED_STANDARDS.md
   └─ kb_index.json

5. Document in 05_AGENTS/02_WORKSHOP/[AGENT]/README.md
   └─ Source: From schoolhouse
   └─ Status: TEMPLATE
   └─ Next step: Development when ready

6. Mark original in schoolhouse for archiving
   └─ Ready to move to ARCHIVE
```

---

## 📂 POST-EXTRACTION STRUCTURE

**In 05_AGENTS/02_WORKSHOP/:**

```
02_WORKSHOP/
├─ [Extracted Agent 1]/        (From schoolhouse)
│  └─ memory/SOPs/
│     └─ 01_[AGENT]_SYSTEM_PROMPT.md
├─ [Extracted Agent 2]/        (From schoolhouse)
├─ [Extracted Agent 3]/        (From schoolhouse)
├─ [Extracted Agent N]/        (From schoolhouse)
├─ RECEPTIONIST_AGENT/         (Previously there)
├─ AIR_AGENT/                  (Previously there)
├─ SECRETARY_AGENT/            (Previously there)
├─ FINANCE_AGENT/              (Previously there)
└─ [Etc - existing agents]
```

---

## 🗂️ ARCHIVE LOCATION

**Old schoolhouse materials:**

```
D:\04_PROJECTS\ARCHIVE\Schoolhouse\

├─ agents/
│  └─ [Extracted agent backups]
│
├─ docs/
│  ├─ training_materials/
│  ├─ educational_content/
│  └─ reference_materials/
│
└─ README.md
   └─ "Schoolhouse archive - educational materials
      Agents extracted to 05_AGENTS/02_WORKSHOP/
      Refer to PROJECT_REGISTRY.md for agent status"
```

---

## ✅ VERIFICATION CHECKLIST

After extraction, verify:

```
☐ All agent folders copied to 05_AGENTS/02_WORKSHOP/
☐ Each agent has proper folder structure
☐ System prompts renamed to 01_[AGENT]_SYSTEM_PROMPT.md
☐ Supporting files created (procedures, links, kb_index)
☐ kb_index.json marked as TEMPLATE
☐ PROJECT_REGISTRY.md updated with new agents
☐ Schoolhouse original moved to ARCHIVE\
☐ No agents left in D:\04_PROJECTS\schoolhouse\
☐ ARCHIVE has README explaining what was moved and why
☐ 05_AGENTS/02_WORKSHOP/ has all agents documented
```

---

## 📊 IMPACT

| Metric | Before | After |
|--------|--------|-------|
| Agents in 05_AGENTS | 8 (1 active + 7 planned) | 8+ (1 active + 7+ templates) |
| Schoolhouse location | D:\04_PROJECTS\ | ARCHIVE\ |
| Space freed in 04_PROJECTS | N/A | 25GB |
| Templates ready for development | 8 | 8+ |

---

## 🎯 AGENT INTEGRATION WITH VBOARDER

**Each extracted agent becomes:**
- A TEMPLATE in 02_WORKSHOP
- Available for future development
- Following shared standards
- Linked to GTD project system
- Ready for deployment when needed

**Workflow:**
```
Extracted Agent (TEMPLATE)
      ↓
Moved to 02_WORKSHOP
      ↓
Reviewed for quality
      ↓
Developed/improved if needed
      ↓
Tested thoroughly
      ↓
Moved to 01_PRODUCTION when ready
```

---

## 📝 DOCUMENTATION

**For each extracted agent, create 02_PROCEDURES.md:**

```markdown
# [AGENT_NAME] Procedures

## Source
- Original source: Schoolhouse (extracted Dec 10, 2025)
- Status: TEMPLATE - Not yet in production

## Template Overview
- [Brief description from original]
- [Key capabilities]
- [Intended purpose]

## Next Steps
1. Review system prompt
2. Identify required refinements
3. Plan for development
4. Integration testing
5. Deployment to production

## Notes
- Extracted as template for future use
- Link to shared standards in SHARED_KNOWLEDGE_BASE
- When ready, move to 01_PRODUCTION

See: PROJECT_REGISTRY.md for current status
```

---

## ⚠️ IMPORTANT NOTES

### **All Extracted Agents Are TEMPLATES**
- Not ready for production immediately
- Marked as TEMPLATE status
- Need review before development
- May require refinement/improvement

### **Shared Standards Apply**
- All agents must follow 03_SHARED_KNOWLEDGE_BASE standards
- Reference mail room operations
- Integrate with INTAKE_COORDINATOR_NAVI
- Use consistent GTD methodology

### **Project Tracking**
- Each agent is tracked in PROJECT_REGISTRY.md
- Status updated as development progresses
- Escalations documented
- Milestones tracked

---

## 🚀 NEXT STEPS

1. **Identify all agents in schoolhouse** (VS agent)
2. **Extract to 05_AGENTS/02_WORKSHOP/** (VS agent)
3. **Create supporting files** (VS agent)
4. **Archive schoolhouse** (VS agent)
5. **Verify and document** (VS agent)
6. **Review and assess** (You - optional, can do later)

---

## 📞 FOR YOUR REFERENCE

**If you want to review extracted agents later:**
- Location: `D:\05_AGENTS\02_WORKSHOP\`
- Check: `02_PROCEDURES.md` for each agent
- Status: See `PROJECT_REGISTRY.md`
- Development: When you decide to build them

**If you need archived schoolhouse materials:**
- Location: `D:\04_PROJECTS\ARCHIVE\Schoolhouse\docs\`
- Content: Training, educational, reference materials
- Accessible: Whenever needed for reference

