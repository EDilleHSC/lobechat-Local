#!/usr/bin/env python3
"""
FILE CLASSIFIER - Categorizes inbox files by type and processing requirement
Routes files to appropriate processing pipelines based on extension and content
"""

import os
from pathlib import Path
from typing import Dict, List

class FileClassifier:
    """Classifies files into categories for intelligent processing"""
    
    # File type mapping
    FILE_TYPES = {
        '.pdf': 'DOCUMENT',
        '.docx': 'DOCUMENT',
        '.doc': 'DOCUMENT',
        '.xlsx': 'SPREADSHEET',
        '.xls': 'SPREADSHEET',
        '.csv': 'DATA',
        '.json': 'DATA',
        '.txt': 'TEXT',
        '.log': 'LOG',
        '.py': 'CODE',
        '.ps1': 'CODE',
        '.md': 'REFERENCE',
        '.jpg': 'IMAGE',
        '.png': 'IMAGE',
        '.gif': 'IMAGE',
        '.eml': 'EMAIL',
        '.msg': 'EMAIL',
    }
    
    # Classification rules
    IGNORE_PATTERNS = [
        'Microsoft.PowerShell_profile',
        'profile.ps1',
        '__pycache__',
        '.pyc',
        'Thumbs.db',
    ]
    
    REFERENCE_ONLY = [
        'GTD_WORKFLOW_GUIDE',
        'README',
        'GUIDE',
        'TEMPLATE',
    ]
    
    HIGH_PRIORITY_KEYWORDS = [
        'urgent', 'asap', 'critical', 'error', 'emergency',
        'deadline', 'overdue', 'action required', 'important'
    ]
    
    @classmethod
    def classify_file(cls, filename: str, file_path: Path = None) -> Dict:
        """Classify a single file"""
        
        # Check if should be ignored
        for ignore_pattern in cls.IGNORE_PATTERNS:
            if ignore_pattern.lower() in filename.lower():
                return {
                    'filename': filename,
                    'classification': 'IGNORE',
                    'reason': 'System/temporary file',
                    'process': False,
                    'priority': 'NONE'
                }
        
        # Get file extension
        ext = Path(filename).suffix.lower()
        file_type = cls.FILE_TYPES.get(ext, 'UNKNOWN')
        
        # Check if reference only
        for ref_pattern in cls.REFERENCE_ONLY:
            if ref_pattern.lower() in filename.lower():
                return {
                    'filename': filename,
                    'classification': 'REFERENCE',
                    'file_type': file_type,
                    'reason': 'Reference material',
                    'process': True,
                    'process_type': 'READ_ONCE',
                    'priority': 'LOW'
                }
        
        # Determine priority based on filename
        priority = cls._determine_priority(filename)
        
        # Determine processing type based on file type
        process_type = cls._get_process_type(file_type, filename)
        
        return {
            'filename': filename,
            'classification': 'ACTION',
            'file_type': file_type,
            'priority': priority,
            'process': True,
            'process_type': process_type,
            'estimated_importance': 'HIGH' if priority in ['URGENT', 'HIGH'] else 'MEDIUM'
        }
    
    @classmethod
    def _determine_priority(cls, filename: str) -> str:
        """Determine file priority from filename"""
        filename_lower = filename.lower()
        
        for keyword in cls.HIGH_PRIORITY_KEYWORDS:
            if keyword in filename_lower:
                return 'URGENT' if 'urgent' in filename_lower or 'error' in filename_lower else 'HIGH'
        
        # Default based on type
        if 'log' in filename_lower or 'error' in filename_lower:
            return 'HIGH'
        elif 'screenshot' in filename_lower or 'image' in filename_lower:
            return 'MEDIUM'
        else:
            return 'MEDIUM'
    
    @classmethod
    def _get_process_type(cls, file_type: str, filename: str) -> str:
        """Determine how to process based on file type"""
        
        process_map = {
            'LOG': 'EXTRACT_ERRORS',
            'CODE': 'ANALYZE_CODE',
            'DOCUMENT': 'EXTRACT_CONTENT',
            'SPREADSHEET': 'EXTRACT_DATA',
            'DATA': 'PARSE_DATA',
            'TEXT': 'READ_EXTRACT',
            'IMAGE': 'DESCRIBE_IMAGE',
            'EMAIL': 'PARSE_EMAIL',
            'REFERENCE': 'READ_ONCE',
            'UNKNOWN': 'READ_PREVIEW'
        }
        
        return process_map.get(file_type, 'READ_PREVIEW')
    
    @classmethod
    def classify_batch(cls, file_list: List[str]) -> Dict:
        """Classify multiple files at once"""
        
        results = {
            'action': [],
            'reference': [],
            'ignore': [],
            'summary': {
                'total': len(file_list),
                'action_required': 0,
                'urgent': 0
            }
        }
        
        for filename in file_list:
            classification = cls.classify_file(filename)
            
            if classification['classification'] == 'ACTION':
                results['action'].append(classification)
                results['summary']['action_required'] += 1
                if classification['priority'] in ['URGENT', 'HIGH']:
                    results['summary']['urgent'] += 1
            elif classification['classification'] == 'REFERENCE':
                results['reference'].append(classification)
            else:
                results['ignore'].append(classification)
        
        return results


if __name__ == "__main__":
    # Test
    test_files = [
        "invoice_2025-11-30.pdf",
        "debug.log",
        "gtd_decision_handler.py",
        "Microsoft.PowerShell_profile.ps1",
        "GTD_WORKFLOW_GUIDE.md",
        "urgent_report.txt",
        "Screenshot 2025-12-05.jpg"
    ]
    
    results = FileClassifier.classify_batch(test_files)
    
    print("=" * 60)
    print("FILE CLASSIFICATION RESULTS")
    print("=" * 60)
    
    print(f"\n📊 SUMMARY: {results['summary']['total']} files")
    print(f"   ✅ Action Required: {results['summary']['action_required']}")
    print(f"   🚨 Urgent: {results['summary']['urgent']}")
    
    print(f"\n📋 ACTION FILES ({len(results['action'])}):")
    for f in results['action']:
        print(f"   - {f['filename']} [{f['file_type']}] Priority: {f['priority']}")
    
    print(f"\n📖 REFERENCE FILES ({len(results['reference'])}):")
    for f in results['reference']:
        print(f"   - {f['filename']}")
    
    print(f"\n🚫 IGNORE FILES ({len(results['ignore'])}):")
    for f in results['ignore']:
        print(f"   - {f['filename']}")
