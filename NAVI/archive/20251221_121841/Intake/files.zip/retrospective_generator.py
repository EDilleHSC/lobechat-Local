#!/usr/bin/env python3
"""
RETROSPECTIVE GENERATOR
Sunday morning (preparing for the week) review system
"""

import json
from pathlib import Path
from datetime import datetime, timedelta
from typing import Dict, List, Any
import logging

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

class RetrospectiveGenerator:
    """Generates weekly retrospectives for process improvement"""
    
    def __init__(self, logs_dir: str, problems_file: str = None):
        self.logs_dir = Path(logs_dir)
        self.problems_file = Path(problems_file) if problems_file else Path("problems_log.json")
        self.retrospectives_dir = self.logs_dir.parent / "retrospectives"
        self.retrospectives_dir.mkdir(exist_ok=True)
    
    def generate_weekly_retrospective(self) -> Dict[str, Any]:
        """
        Generate comprehensive weekly retrospective
        Run every Sunday morning
        """
        
        logger.info("🔄 Generating weekly retrospective...")
        
        # Get data from past week
        week_logs = self._get_week_logs()
        metrics = self._calculate_metrics(week_logs)
        problems = self._identify_problems(week_logs)
        improvements = self._suggest_improvements(problems)
        
        retrospective = {
            "generated_at": datetime.now().isoformat(),
            "period": "week",
            "week_start": (datetime.now() - timedelta(days=7)).strftime("%Y-%m-%d"),
            "week_end": datetime.now().strftime("%Y-%m-%d"),
            "metrics": metrics,
            "problems": problems,
            "improvements": improvements,
            "action_items": self._generate_action_items(improvements),
            "phase_readiness": self._check_phase_readiness(metrics)
        }
        
        # Save retrospective
        filename = self.retrospectives_dir / f"retrospective_{datetime.now().strftime('%Y-%m-%d')}.json"
        with open(filename, 'w') as f:
            json.dump(retrospective, f, indent=2)
        
        logger.info(f"✅ Retrospective saved: {filename}")
        
        return retrospective
    
    def _get_week_logs(self) -> List[Dict]:
        """Get all session logs from past week"""
        
        week_ago = datetime.now() - timedelta(days=7)
        logs = []
        
        for log_file in self.logs_dir.glob("session_log_*.json"):
            try:
                file_time = datetime.fromisoformat(log_file.stem.split('_')[2])
                if file_time >= week_ago:
                    with open(log_file, 'r') as f:
                        logs.append(json.load(f))
            except Exception as e:
                logger.warning(f"Could not read {log_file}: {e}")
        
        return logs
    
    def _calculate_metrics(self, logs: List[Dict]) -> Dict[str, Any]:
        """Calculate key metrics from session logs"""
        
        if not logs:
            return {
                "sessions": 0,
                "files_processed": 0,
                "accuracy": 0,
                "batch_size_avg": 0,
                "processing_speed": 0
            }
        
        total_files = sum(log.get("files_processed", 0) for log in logs)
        total_corrections = sum(len(log.get("user_corrections", [])) for log in logs)
        total_accuracy = sum(log.get("metrics", {}).get("navi_accuracy", 100) for log in logs) / len(logs)
        
        return {
            "sessions_completed": len(logs),
            "total_files_processed": total_files,
            "files_per_session_avg": total_files / len(logs) if logs else 0,
            "navi_accuracy_percent": round(total_accuracy, 1),
            "user_corrections_total": total_corrections,
            "correction_rate_percent": round((total_corrections / total_files * 100) if total_files else 0, 1),
            "improvement_trend": self._calculate_trend(logs)
        }
    
    def _calculate_trend(self, logs: List[Dict]) -> str:
        """Calculate if accuracy is improving"""
        
        if len(logs) < 2:
            return "Insufficient data"
        
        first_half_accuracy = sum(
            log.get("metrics", {}).get("navi_accuracy", 100) 
            for log in logs[:len(logs)//2]
        ) / (len(logs)//2)
        
        second_half_accuracy = sum(
            log.get("metrics", {}).get("navi_accuracy", 100) 
            for log in logs[len(logs)//2:]
        ) / (len(logs) - len(logs)//2)
        
        improvement = second_half_accuracy - first_half_accuracy
        
        if improvement > 2:
            return f"📈 Improving (+{improvement:.1f}%)"
        elif improvement < -2:
            return f"📉 Declining ({improvement:.1f}%)"
        else:
            return "➡️ Stable"
    
    def _identify_problems(self, logs: List[Dict]) -> List[Dict]:
        """Identify problems from logs"""
        
        problems = []
        corrections_by_type = {}
        
        # Analyze corrections
        for log in logs:
            for correction in log.get("user_corrections", []):
                file_type = correction.get("file", "").split('.')[-1]
                if file_type not in corrections_by_type:
                    corrections_by_type[file_type] = 0
                corrections_by_type[file_type] += 1
        
        # Identify patterns
        for file_type, count in sorted(corrections_by_type.items(), key=lambda x: x[1], reverse=True):
            if count >= 2:
                problems.append({
                    "issue": f"{file_type.upper()} files misclassified",
                    "count": count,
                    "impact": "medium" if count < 3 else "high",
                    "status": "IDENTIFIED",
                    "file_type": file_type,
                    "requires_fix": True
                })
        
        # Check for stuck files
        if any(log.get("stuck_in_waiting", 0) > 0 for log in logs):
            total_stuck = sum(log.get("stuck_in_waiting", 0) for log in logs)
            problems.append({
                "issue": "Files stuck in WAITING > 7 days",
                "count": total_stuck,
                "impact": "high",
                "status": "IDENTIFIED",
                "requires_fix": True
            })
        
        return problems
    
    def _suggest_improvements(self, problems: List[Dict]) -> List[Dict]:
        """Suggest improvements based on problems"""
        
        improvements = []
        
        for problem in problems:
            if problem["issue"] == "Files stuck in WAITING > 7 days":
                improvements.append({
                    "problem": problem["issue"],
                    "suggested_fix": "Add weekly WAITING folder review protocol",
                    "implementation": "Auto-flag files > 7 days, show user on Sunday",
                    "effort": "LOW",
                    "priority": "HIGH"
                })
            
            elif "misclassified" in problem["issue"]:
                file_type = problem["file_type"]
                improvements.append({
                    "problem": problem["issue"],
                    "suggested_fix": f"Create special classification rule for {file_type} files",
                    "implementation": f"Add IF filename.{file_type} → check for specific keywords",
                    "effort": "LOW",
                    "priority": "MEDIUM"
                })
        
        return improvements
    
    def _generate_action_items(self, improvements: List[Dict]) -> List[Dict]:
        """Generate concrete action items for the week"""
        
        action_items = []
        
        for i, improvement in enumerate(improvements, 1):
            action_items.append({
                "priority": improvement["priority"],
                "task": improvement["suggested_fix"],
                "owner": "Navi",
                "deadline": (datetime.now() + timedelta(days=7)).strftime("%Y-%m-%d"),
                "status": "NOT_STARTED",
                "order": i
            })
        
        return action_items
    
    def _check_phase_readiness(self, metrics: Dict) -> Dict:
        """Check if ready to advance to next phase"""
        
        accuracy = metrics.get("navi_accuracy_percent", 0)
        
        return {
            "current_performance": {
                "accuracy_percent": accuracy,
                "sessions_completed": metrics.get("sessions_completed", 0),
                "total_files": metrics.get("total_files_processed", 0)
            },
            "phase_1_complete": accuracy >= 95 and metrics.get("sessions_completed", 0) >= 5,
            "phase_2_ready": accuracy >= 96 and metrics.get("total_files_processed", 0) >= 50,
            "phase_3_ready": accuracy >= 97 and metrics.get("total_files_processed", 0) >= 200,
            "phase_4_ready": accuracy >= 98 and metrics.get("total_files_processed", 0) >= 500,
            "recommendation": self._get_phase_recommendation(accuracy, metrics.get("sessions_completed", 0))
        }
    
    def _get_phase_recommendation(self, accuracy: float, sessions: int) -> str:
        """Get recommendation for next phase"""
        
        if accuracy < 90:
            return "🔴 Continue Phase 1 - Accuracy below threshold"
        elif accuracy < 95:
            return "🟡 Continue Phase 1 - Needs more data"
        elif accuracy >= 95 and sessions >= 5:
            return "🟢 Ready for Phase 2 - Increase batch size to 10"
        elif accuracy >= 96 and sessions >= 10:
            return "🟢 Ready for Phase 3 - Increase batch size to 20"
        else:
            return "➡️ Continue current phase"
    
    def generate_daily_summary(self) -> str:
        """Quick daily summary (different from weekly)"""
        
        # Get today's logs
        today_logs = []
        for log_file in self.logs_dir.glob("session_log_*.json"):
            try:
                file_date = log_file.stem.split('_')[2]
                if file_date == datetime.now().strftime("%Y-%m-%d"):
                    with open(log_file, 'r') as f:
                        today_logs.append(json.load(f))
            except Exception:
                pass
        
        if not today_logs:
            return "No sessions completed today yet."
        
        total_files = sum(log.get("files_processed", 0) for log in today_logs)
        avg_accuracy = sum(log.get("metrics", {}).get("navi_accuracy", 100) for log in today_logs) / len(today_logs)
        
        return f"""
═══════════════════════════════════════
DAILY SUMMARY - {datetime.now().strftime("%Y-%m-%d")}
═══════════════════════════════════════

📊 FILES PROCESSED: {total_files}
✅ NAVI ACCURACY: {avg_accuracy:.1f}%
📋 SESSIONS: {len(today_logs)}

Ready for tomorrow! 🚀
"""
    
    def format_retrospective_for_display(self, retrospective: Dict) -> str:
        """Format retrospective for user display"""
        
        output = f"""
════════════════════════════════════════════════════
WEEKLY RETROSPECTIVE - Week ending {retrospective['week_end']}
════════════════════════════════════════════════════

📊 BY THE NUMBERS:
├─ Sessions: {retrospective['metrics']['sessions_completed']}
├─ Files processed: {retrospective['metrics']['total_files_processed']}
├─ Avg files/session: {retrospective['metrics']['files_per_session_avg']:.1f}
├─ Navi accuracy: {retrospective['metrics']['navi_accuracy_percent']}%
├─ Correction rate: {retrospective['metrics']['correction_rate_percent']}%
└─ Trend: {retrospective['metrics']['improvement_trend']}

"""
        
        if retrospective['problems']:
            output += f"""🚨 PROBLEMS IDENTIFIED:
"""
            for i, problem in enumerate(retrospective['problems'], 1):
                output += f"""├─ {problem['issue']} ({problem['count']} occurrences)
"""
            output += "\n"
        
        if retrospective['improvements']:
            output += f"""✅ IMPROVEMENTS RECOMMENDED:
"""
            for improvement in retrospective['improvements'][:3]:  # Top 3
                output += f"""├─ {improvement['suggested_fix']}
│  Effort: {improvement['effort']} | Priority: {improvement['priority']}
"""
            output += "\n"
        
        output += f"""
📈 NEXT PHASE READINESS:
{retrospective['phase_readiness']['recommendation']}

📋 ACTION ITEMS FOR THIS WEEK:
"""
        
        for item in retrospective['action_items'][:5]:  # Top 5
            output += f"""├─ [{item['priority']}] {item['task']}
│  Due: {item['deadline']}
"""
        
        output += "\n════════════════════════════════════════════════════\n"
        
        return output


if __name__ == "__main__":
    # Test
    gen = RetrospectiveGenerator("D:\\05_AGENTS\\NAVI_RECEPTIONIST\\intelligence")
    
    # Generate retrospective
    retro = gen.generate_weekly_retrospective()
    
    print(gen.format_retrospective_for_display(retro))
