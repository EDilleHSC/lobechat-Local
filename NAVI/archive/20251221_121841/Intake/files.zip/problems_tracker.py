#!/usr/bin/env python3
"""
PROBLEMS TRACKER & FIXER
Identifies problems, tracks root causes, implements fixes, monitors improvements
"""

import json
from pathlib import Path
from datetime import datetime
from typing import Dict, List, Any
import logging

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

class ProblemsTracker:
    """Tracks problems and manages continuous improvement"""
    
    def __init__(self, problems_file: str = "problems_log.json"):
        self.problems_file = Path(problems_file)
        self.problems = self._load_problems()
    
    def _load_problems(self) -> List[Dict]:
        """Load existing problems log"""
        if self.problems_file.exists():
            with open(self.problems_file, 'r') as f:
                return json.load(f)
        return []
    
    def report_problem(self, issue: str, count: int, impact: str, 
                      category: str = "CLASSIFICATION", source_file: str = "") -> Dict:
        """
        Report a new problem
        
        Categories: CLASSIFICATION, PERFORMANCE, WORKFLOW, EXCEPTION, OTHER
        Impact: LOW, MEDIUM, HIGH, CRITICAL
        """
        
        logger.info(f"📋 Problem reported: {issue}")
        
        problem = {
            "id": f"PROBLEM_{len(self.problems) + 1:04d}",
            "reported_date": datetime.now().isoformat(),
            "issue": issue,
            "category": category,
            "count": count,
            "impact": impact,
            "source_file": source_file,
            "status": "OPEN",
            "root_cause": None,
            "proposed_fix": None,
            "fix_implemented_date": None,
            "fix_verified": False,
            "improvement_percent": 0,
            "similar_problems": []
        }
        
        # Check for similar problems
        similar = self._find_similar_problems(issue)
        if similar:
            problem["similar_problems"] = [p["id"] for p in similar]
            logger.info(f"⚠️ Found {len(similar)} similar problems")
        
        self.problems.append(problem)
        self._save_problems()
        
        return problem
    
    def _find_similar_problems(self, issue: str) -> List[Dict]:
        """Find similar problems already tracked"""
        
        keywords = set(issue.lower().split())
        similar = []
        
        for problem in self.problems:
            if problem["status"] == "CLOSED":
                continue
            
            problem_keywords = set(problem["issue"].lower().split())
            overlap = len(keywords & problem_keywords)
            
            if overlap >= 2:  # At least 2 common words
                similar.append(problem)
        
        return similar
    
    def analyze_root_cause(self, problem_id: str, root_cause: str) -> Dict:
        """
        Analyze and document root cause
        
        Example: "ChatGPT log classification rule missing"
        """
        
        problem = self._find_problem(problem_id)
        if not problem:
            return {"error": f"Problem {problem_id} not found"}
        
        logger.info(f"🔍 Analyzing root cause for {problem_id}")
        
        problem["root_cause"] = root_cause
        problem["status"] = "ROOT_CAUSE_IDENTIFIED"
        
        self._save_problems()
        
        return {
            "problem_id": problem_id,
            "issue": problem["issue"],
            "root_cause": root_cause,
            "next_step": "Propose a fix"
        }
    
    def propose_fix(self, problem_id: str, fix_description: str, 
                   implementation_steps: List[str] = None) -> Dict:
        """
        Propose a fix for the problem
        """
        
        problem = self._find_problem(problem_id)
        if not problem:
            return {"error": f"Problem {problem_id} not found"}
        
        logger.info(f"🔧 Proposing fix for {problem_id}")
        
        problem["proposed_fix"] = {
            "description": fix_description,
            "implementation_steps": implementation_steps or [],
            "proposed_date": datetime.now().isoformat(),
            "status": "PROPOSED"
        }
        problem["status"] = "FIX_PROPOSED"
        
        self._save_problems()
        
        return {
            "problem_id": problem_id,
            "issue": problem["issue"],
            "proposed_fix": fix_description,
            "steps": implementation_steps or [],
            "next_step": "Implement the fix"
        }
    
    def implement_fix(self, problem_id: str, implementation_notes: str = "") -> Dict:
        """
        Mark fix as implemented
        """
        
        problem = self._find_problem(problem_id)
        if not problem:
            return {"error": f"Problem {problem_id} not found"}
        
        logger.info(f"✅ Implementing fix for {problem_id}")
        
        problem["fix_implemented_date"] = datetime.now().isoformat()
        problem["status"] = "FIX_IMPLEMENTED"
        problem["implementation_notes"] = implementation_notes
        
        self._save_problems()
        
        return {
            "problem_id": problem_id,
            "issue": problem["issue"],
            "status": "FIX_IMPLEMENTED",
            "message": "Fix is now active. Monitoring for improvement..."
        }
    
    def verify_fix(self, problem_id: str, improvement_percent: float, 
                   verification_notes: str = "") -> Dict:
        """
        Verify that fix works and measure improvement
        """
        
        problem = self._find_problem(problem_id)
        if not problem:
            return {"error": f"Problem {problem_id} not found"}
        
        logger.info(f"✔️ Verifying fix for {problem_id}")
        
        problem["fix_verified"] = True
        problem["improvement_percent"] = improvement_percent
        problem["verification_date"] = datetime.now().isoformat()
        problem["verification_notes"] = verification_notes
        
        if improvement_percent >= 80:
            problem["status"] = "CLOSED"
            logger.info(f"🎉 Problem {problem_id} CLOSED - {improvement_percent}% improvement")
        else:
            problem["status"] = "IMPROVEMENT_PARTIAL"
            logger.warning(f"⚠️ Problem {problem_id} partially fixed - {improvement_percent}% improvement")
        
        self._save_problems()
        
        return {
            "problem_id": problem_id,
            "issue": problem["issue"],
            "improvement_percent": improvement_percent,
            "status": problem["status"],
            "message": f"Problem improved by {improvement_percent}%"
        }
    
    def get_problem_status(self, problem_id: str = None) -> Dict:
        """Get status of problem(s)"""
        
        if problem_id:
            problem = self._find_problem(problem_id)
            return problem if problem else {"error": f"Problem {problem_id} not found"}
        
        # Return all problems grouped by status
        by_status = {}
        for problem in self.problems:
            status = problem["status"]
            if status not in by_status:
                by_status[status] = []
            by_status[status].append(problem)
        
        return by_status
    
    def _find_problem(self, problem_id: str) -> Dict:
        """Find a problem by ID"""
        for problem in self.problems:
            if problem["id"] == problem_id:
                return problem
        return None
    
    def get_learning_summary(self) -> Dict:
        """Get summary of what was learned"""
        
        closed_problems = [p for p in self.problems if p["status"] == "CLOSED"]
        
        if not closed_problems:
            return {"closed_problems": 0, "learnings": []}
        
        learnings = []
        for problem in closed_problems:
            learnings.append({
                "issue": problem["issue"],
                "root_cause": problem["root_cause"],
                "fix": problem["proposed_fix"]["description"] if problem["proposed_fix"] else None,
                "improvement": problem["improvement_percent"],
                "closed_date": problem["verification_date"]
            })
        
        return {
            "closed_problems": len(closed_problems),
            "average_improvement": sum(p["improvement_percent"] for p in closed_problems) / len(closed_problems),
            "learnings": learnings
        }
    
    def _save_problems(self):
        """Save problems to file"""
        with open(self.problems_file, 'w') as f:
            json.dump(self.problems, f, indent=2)
    
    def get_open_problems(self) -> List[Dict]:
        """Get all open problems"""
        return [p for p in self.problems if p["status"] != "CLOSED"]
    
    def get_problems_by_category(self) -> Dict:
        """Group problems by category"""
        by_category = {}
        for problem in self.problems:
            category = problem.get("category", "OTHER")
            if category not in by_category:
                by_category[category] = []
            by_category[category].append(problem)
        return by_category
    
    def format_problem_status_for_display(self, problem: Dict) -> str:
        """Format problem status for user display"""
        
        output = f"""
{'═' * 60}
PROBLEM: {problem['issue']}
ID: {problem['id']} | Status: {problem['status']} | Impact: {problem['impact']}
Reported: {problem['reported_date'][:10]}
{'═' * 60}

"""
        
        if problem['count']:
            output += f"Occurrences: {problem['count']}\n"
        
        if problem['root_cause']:
            output += f"Root Cause: {problem['root_cause']}\n"
        
        if problem['proposed_fix']:
            output += f"Proposed Fix: {problem['proposed_fix']['description']}\n"
        
        if problem['fix_implemented_date']:
            output += f"Implemented: {problem['fix_implemented_date'][:10]}\n"
        
        if problem['fix_verified']:
            output += f"Improvement: +{problem['improvement_percent']}%\n"
        
        if problem['similar_problems']:
            output += f"Related Problems: {', '.join(problem['similar_problems'])}\n"
        
        output += f"\n{'═' * 60}\n"
        
        return output


if __name__ == "__main__":
    # Test
    tracker = ProblemsTracker()
    
    # Report problem
    problem = tracker.report_problem(
        issue="ChatGPT logs misclassified",
        count=2,
        impact="MEDIUM",
        category="CLASSIFICATION"
    )
    print(f"✅ Problem reported: {problem['id']}")
    
    # Analyze root cause
    cause = tracker.analyze_root_cause(
        problem['id'],
        "Classification rule looks for 'action' keyword, which appears in all ChatGPT logs"
    )
    print(f"🔍 Root cause analyzed")
    
    # Propose fix
    fix = tracker.propose_fix(
        problem['id'],
        "Create special classification rule for ChatGPT log files",
        ["Check if filename contains 'ChatGPT'", 
         "Only mark as urgent if explicit deadline found",
         "Otherwise default to [STANDARD]"]
    )
    print(f"🔧 Fix proposed")
    
    # Implement fix
    impl = tracker.implement_fix(
        problem['id'],
        "Added IF condition to classify_file() method"
    )
    print(f"✅ Fix implemented")
    
    # Verify fix
    verify = tracker.verify_fix(
        problem['id'],
        100,
        "Tested on 10 ChatGPT logs - all correctly classified"
    )
    print(f"✔️ Fix verified - 100% improvement")
    
    # Show status
    status = tracker.get_problem_status(problem['id'])
    print(tracker.format_problem_status_for_display(status))
