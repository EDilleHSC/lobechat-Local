#!/usr/bin/env python3
"""
DATA EXTRACTOR - Reads files and extracts intelligent data
Pulls key info: dates, amounts, errors, action items, metadata
"""

from pathlib import Path
from typing import Dict, List, Any
import re
from datetime import datetime

class DataExtractor:
    """Extracts key data from different file types"""
    
    # Patterns to find
    PATTERNS = {
        'email': r'[\w\.-]+@[\w\.-]+\.\w+',
        'phone': r'\+?1?\d{3}[-.]?\d{3}[-.]?\d{4}',
        'amount': r'\$[\d,]+\.?\d*',
        'date': r'\d{1,2}/\d{1,2}/\d{4}|\d{4}-\d{2}-\d{2}',
        'url': r'https?://\S+',
        'urgency': r'(urgent|asap|critical|emergency|priority)',
        'action': r'(action\s+required|to\s+do|todo|must|should|need)',
    }
    
    @classmethod
    def extract_from_file(cls, file_path: Path) -> Dict[str, Any]:
        """Extract data from a file"""
        
        if not file_path.exists():
            return {'error': f'File not found: {file_path}'}
        
        file_ext = file_path.suffix.lower()
        filename = file_path.name
        
        # Basic file info
        file_info = {
            'filename': filename,
            'path': str(file_path),
            'size_bytes': file_path.stat().st_size,
            'modified': datetime.fromtimestamp(file_path.stat().st_mtime).isoformat(),
            'extension': file_ext,
        }
        
        # Read content based on type
        try:
            if file_ext in ['.txt', '.log', '.md', '.py', '.ps1']:
                content = cls._read_text_file(file_path)
                extracted = cls._extract_from_text(content, filename)
            elif file_ext in ['.pdf', '.docx', '.doc']:
                extracted = cls._extract_from_document(file_path)
            elif file_ext in ['.xlsx', '.xls', '.csv']:
                extracted = cls._extract_from_spreadsheet(file_path)
            elif file_ext in ['.json']:
                extracted = cls._extract_from_json(file_path)
            elif file_ext in ['.jpg', '.png', '.gif']:
                extracted = cls._extract_from_image(file_path)
            else:
                extracted = {'summary': 'File type not yet supported for detailed extraction'}
        except Exception as e:
            extracted = {'error': str(e), 'summary': f'Error reading {filename}'}
        
        return {**file_info, **extracted}
    
    @classmethod
    def _read_text_file(cls, file_path: Path, max_chars: int = 2000) -> str:
        """Read text file content"""
        try:
            with open(file_path, 'r', encoding='utf-8', errors='ignore') as f:
                return f.read(max_chars)
        except Exception as e:
            return f"Error reading file: {e}"
    
    @classmethod
    def _extract_from_text(cls, content: str, filename: str) -> Dict:
        """Extract data from text content"""
        
        extracted = {
            'summary': content[:500] if len(content) > 500 else content,
            'length': len(content),
            'entities': {}
        }
        
        # Find patterns
        for pattern_type, pattern in cls.PATTERNS.items():
            matches = re.findall(pattern, content, re.IGNORECASE)
            if matches:
                extracted['entities'][pattern_type] = list(set(matches))[:5]  # Top 5
        
        # Special handling for logs
        if 'log' in filename.lower():
            errors = re.findall(r'error.*', content, re.IGNORECASE)
            warnings = re.findall(r'warning.*', content, re.IGNORECASE)
            extracted['errors'] = errors[:5] if errors else []
            extracted['warnings'] = warnings[:5] if warnings else []
        
        # Check for urgency
        if re.search(cls.PATTERNS['urgency'], content, re.IGNORECASE):
            extracted['urgency_detected'] = True
        
        return extracted
    
    @classmethod
    def _extract_from_document(cls, file_path: Path) -> Dict:
        """Extract from PDF/DOCX documents"""
        # Simplified - in production use pypdf/python-docx
        return {
            'summary': 'Document detected (detailed extraction requires pypdf)',
            'type': 'DOCUMENT',
            'estimated_pages': 'Unknown'
        }
    
    @classmethod
    def _extract_from_spreadsheet(cls, file_path: Path) -> Dict:
        """Extract from Excel/CSV"""
        # Simplified - in production use openpyxl/pandas
        return {
            'summary': 'Spreadsheet detected (detailed extraction requires openpyxl)',
            'type': 'SPREADSHEET',
            'rows': 'Unknown'
        }
    
    @classmethod
    def _extract_from_json(cls, file_path: Path) -> Dict:
        """Extract from JSON file"""
        try:
            import json
            with open(file_path, 'r') as f:
                data = json.load(f)
            return {
                'summary': f'JSON data with {len(data)} keys' if isinstance(data, dict) else f'JSON array with {len(data)} items',
                'data_keys': list(data.keys())[:5] if isinstance(data, dict) else None,
                'type': 'DATA'
            }
        except Exception as e:
            return {'error': str(e)}
    
    @classmethod
    def _extract_from_image(cls, file_path: Path) -> Dict:
        """Extract from image files"""
        # Simplified - in production use PIL/OCR
        return {
            'summary': 'Image file detected',
            'type': 'IMAGE',
            'needs_manual_review': True
        }
    
    @classmethod
    def batch_extract(cls, file_list: List[Path]) -> Dict[str, Dict]:
        """Extract from multiple files"""
        results = {}
        for file_path in file_list:
            if file_path.exists() and file_path.is_file():
                results[file_path.name] = cls.extract_from_file(file_path)
        return results


if __name__ == "__main__":
    # Test
    test_file = Path("test.txt")
    test_file.write_text("URGENT: Error in system. Amount: $5,000. Contact: john@example.com. Action required ASAP!")
    
    result = DataExtractor.extract_from_file(test_file)
    
    print("=" * 60)
    print("DATA EXTRACTION RESULT")
    print("=" * 60)
    for key, value in result.items():
        print(f"{key}: {value}")
    
    test_file.unlink()  # cleanup
