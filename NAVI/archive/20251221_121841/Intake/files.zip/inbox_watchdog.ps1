# INBOX WATCHDOG & PROCESSOR
# Continuously monitors inbox, processes files, generates intelligence

param(
    [string]$InboxPath = "D:\05_AGENTS\NAVI_RECEPTIONIST\inbox",
    [string]$IntelligencePath = "D:\05_AGENTS\NAVI_RECEPTIONIST\intelligence",
    [string]$ProcessorScript = "D:\05_AGENTS\NAVI_RECEPTIONIST\scripts\inbox_processor.py",
    [int]$CheckIntervalSeconds = 30
)

# Create directories if needed
if (-not (Test-Path $InboxPath)) {
    Write-Host "❌ Inbox path not found: $InboxPath" -ForegroundColor Red
    exit
}

if (-not (Test-Path $IntelligencePath)) {
    New-Item -ItemType Directory -Path $IntelligencePath -Force | Out-Null
    Write-Host "✅ Created intelligence directory: $IntelligencePath" -ForegroundColor Green
}

# Log file
$LogFile = Join-Path $IntelligencePath "watchdog.log"

function Log {
    param([string]$Message)
    $Timestamp = Get-Date -Format "yyyy-MM-dd HH:mm:ss"
    $LogEntry = "[$Timestamp] $Message"
    Write-Host $LogEntry
    Add-Content -Path $LogFile -Value $LogEntry
}

function Get-FileHashes {
    param([string]$Path)
    
    $files = Get-ChildItem -Path $Path -File
    $hashes = @()
    
    foreach ($file in $files) {
        $hash = @{
            Name = $file.Name
            Size = $file.Length
            Modified = $file.LastWriteTime
        }
        $hashes += $hash
    }
    
    return $hashes
}

function Process-Inbox {
    Log "🔄 Processing inbox..."
    
    try {
        # Run Python processor
        if (Test-Path $ProcessorScript) {
            python $ProcessorScript | Out-Null
            Log "✅ Inbox processed successfully"
        } else {
            Log "⚠️ Processor script not found: $ProcessorScript"
        }
    }
    catch {
        Log "❌ Error processing inbox: $_"
    }
}

function Analyze-Changes {
    param(
        [array]$CurrentFiles,
        [array]$LastFiles
    )
    
    if ($null -eq $LastFiles -or $LastFiles.Count -eq 0) {
        return @{ New = $CurrentFiles; Removed = @(); Changed = @() }
    }
    
    $newFiles = @()
    $removedFiles = @()
    $changedFiles = @()
    
    # Find new files
    foreach ($file in $CurrentFiles) {
        $found = $LastFiles | Where-Object { $_.Name -eq $file.Name }
        if (-not $found) {
            $newFiles += $file
        }
        elseif ($found.Modified -ne $file.Modified) {
            $changedFiles += $file
        }
    }
    
    # Find removed files
    foreach ($file in $LastFiles) {
        $found = $CurrentFiles | Where-Object { $_.Name -eq $file.Name }
        if (-not $found) {
            $removedFiles += $file
        }
    }
    
    return @{
        New = $newFiles
        Removed = $removedFiles
        Changed = $changedFiles
    }
}

function Display-Inbox-Summary {
    param([string]$InboxPath)
    
    $files = Get-ChildItem -Path $InboxPath -File
    $totalSize = ($files | Measure-Object -Property Length -Sum).Sum
    
    Write-Host ""
    Write-Host "=" * 60 -ForegroundColor Cyan
    Write-Host "📦 INBOX SUMMARY" -ForegroundColor Cyan
    Write-Host "=" * 60 -ForegroundColor Cyan
    Write-Host "Total Files: $($files.Count)"
    Write-Host "Total Size: $('{0:N0}' -f $totalSize) bytes"
    Write-Host ""
    
    if ($files.Count -gt 0) {
        Write-Host "📄 FILES:" -ForegroundColor Yellow
        $files | ForEach-Object {
            $size = '{0:N0}' -f $_.Length
            Write-Host "  - $($_.Name) ($size bytes)"
        }
    } else {
        Write-Host "📭 Inbox is empty" -ForegroundColor Green
    }
    
    Write-Host "=" * 60 -ForegroundColor Cyan
    Write-Host ""
}

# Main loop
Log "🚀 Inbox Watchdog started"
Log "📍 Inbox: $InboxPath"
Log "📍 Intelligence: $IntelligencePath"
Log "⏱️ Check interval: $CheckIntervalSeconds seconds"

$lastFileState = @()
$processCount = 0

while ($true) {
    try {
        # Get current files
        $currentFiles = Get-FileHashes -Path $InboxPath
        
        # Analyze changes
        $changes = Analyze-Changes -CurrentFiles $currentFiles -LastFiles $lastFileState
        
        # Report changes
        if ($changes.New.Count -gt 0) {
            Log "✨ NEW FILES DETECTED: $($changes.New.Count)"
            $changes.New | ForEach-Object {
                Log "   ➕ $($_.Name)"
            }
            
            # Trigger processing
            Process-Inbox
            $processCount++
        }
        
        if ($changes.Removed.Count -gt 0) {
            Log "🗑️ FILES REMOVED: $($changes.Removed.Count)"
            $changes.Removed | ForEach-Object {
                Log "   ➖ $($_.Name)"
            }
            
            # Trigger reprocessing
            Process-Inbox
            $processCount++
        }
        
        if ($changes.Changed.Count -gt 0) {
            Log "📝 FILES MODIFIED: $($changes.Changed.Count)"
            $changes.Changed | ForEach-Object {
                Log "   ✏️ $($_.Name)"
            }
        }
        
        # Every 10 checks, display summary
        if ($processCount % 10 -eq 0) {
            Display-Inbox-Summary -InboxPath $InboxPath
        }
        
        # Update state
        $lastFileState = $currentFiles
        
        # Wait before next check
        Start-Sleep -Seconds $CheckIntervalSeconds
    }
    catch {
        Log "⚠️ Error in watchdog loop: $_"
        Start-Sleep -Seconds $CheckIntervalSeconds
    }
}
