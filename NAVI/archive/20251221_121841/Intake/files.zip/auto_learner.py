#!/usr/bin/env python3
"""
AUTO-LEARNER
Navi learns from your corrections and improves classification accuracy over time
"""

import json
from pathlib import Path
from datetime import datetime
from typing import Dict, List, Any
from collections import defaultdict
import logging

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

class AutoLearner:
    """Handles Navi's learning from user corrections"""
    
    def __init__(self, rules_file: str = "navi_learning_rules.json"):
        self.rules_file = Path(rules_file)
        self.learning_rules = self._load_rules()
        self.correction_history = defaultdict(list)
    
    def _load_rules(self) -> Dict:
        """Load existing learning rules"""
        if self.rules_file.exists():
            with open(self.rules_file, 'r') as f:
                return json.load(f)
        return {
            "file_type_rules": {},
            "keyword_rules": {},
            "pattern_rules": {},
            "exception_rules": {},
            "last_updated": datetime.now().isoformat(),
            "total_corrections_learned": 0
        }
    
    def learn_from_correction(self, filename: str, navi_tagged: str, 
                             user_corrected_to: str, reason: str = "") -> Dict:
        """
        Learn from user correction
        
        Example:
        filename = "chatgpt_log.txt"
        navi_tagged = "[24HR]"
        user_corrected_to = "[STANDARD]"
        reason = "ChatGPT logs shouldn't be marked urgent"
        """
        
        logger.info(f"📚 Learning from correction: {filename}")
        logger.info(f"   Navi said: {navi_tagged} → You said: {user_corrected_to}")
        
        # Record the correction
        correction = {
            "timestamp": datetime.now().isoformat(),
            "filename": filename,
            "navi_tagged": navi_tagged,
            "user_corrected_to": user_corrected_to,
            "reason": reason,
            "file_extension": Path(filename).suffix,
            "file_type": self._classify_file_type(filename)
        }
        
        self.correction_history[filename] = correction
        
        # Extract learning
        learning = self._extract_learning_pattern(correction)
        
        # Update rules
        self._update_rules(learning)
        
        logger.info(f"✅ Learning applied: {learning['rule_type']}")
        
        return {
            "status": "LEARNING_APPLIED",
            "correction": correction,
            "learning": learning,
            "improvement_opportunity": True
        }
    
    def _classify_file_type(self, filename: str) -> str:
        """Classify file type"""
        
        ext = Path(filename).suffix.lower()
        
        file_types = {
            '.log': 'LOG',
            '.txt': 'TEXT',
            '.pdf': 'DOCUMENT',
            '.xlsx': 'SPREADSHEET',
            '.docx': 'DOCUMENT',
            '.py': 'CODE',
            '.json': 'DATA',
            '.csv': 'DATA',
            '.jpg': 'IMAGE',
            '.png': 'IMAGE'
        }
        
        return file_types.get(ext, 'UNKNOWN')
    
    def _extract_learning_pattern(self, correction: Dict) -> Dict:
        """Extract learning pattern from correction"""
        
        filename = correction['filename'].lower()
        file_extension = correction['file_extension']
        file_type = correction['file_type']
        navi_tagged = correction['navi_tagged']
        user_corrected = correction['user_corrected_to']
        
        learning = {
            "rule_type": "GENERIC",
            "pattern": None,
            "condition": None,
            "action": user_corrected,
            "confidence": 0.8
        }
        
        # PATTERN 1: ChatGPT-specific
        if 'chatgpt' in filename or 'conversation' in filename:
            learning["rule_type"] = "SPECIAL_FILE_TYPE"
            learning["pattern"] = "ChatGPT logs should default to [STANDARD] unless explicit deadline"
            learning["condition"] = "IF filename contains 'chatgpt' OR 'conversation'"
            learning["confidence"] = 0.95
        
        # PATTERN 2: File type based
        elif navi_tagged != user_corrected and file_type:
            learning["rule_type"] = "FILE_TYPE_RULE"
            learning["pattern"] = f"{file_type} files should be tagged {user_corrected}"
            learning["condition"] = f"IF file_type == '{file_type}'"
            learning["confidence"] = 0.85
        
        # PATTERN 3: Keyword based
        elif any(kw in filename for kw in ['log', 'debug', 'error', 'trace']):
            if 'error' in filename and user_corrected == "[IMMEDIATE]":
                learning["rule_type"] = "KEYWORD_RULE"
                learning["pattern"] = "Error files are more urgent than logs"
                learning["condition"] = "IF 'error' in filename"
                learning["confidence"] = 0.9
        
        # PATTERN 4: Exception
        else:
            learning["rule_type"] = "EXCEPTION_RULE"
            learning["pattern"] = f"{filename} specific exception"
            learning["condition"] = f"IF filename == '{filename}'"
            learning["confidence"] = 0.5  # Lower confidence for one-off exceptions
        
        return learning
    
    def _update_rules(self, learning: Dict):
        """Update learning rules based on correction"""
        
        rule_type = learning["rule_type"]
        
        if rule_type == "FILE_TYPE_RULE":
            # Extract file extension from last correction
            last_corr = list(self.correction_history.values())[-1]
            ext = last_corr['file_extension']
            
            if ext not in self.learning_rules["file_type_rules"]:
                self.learning_rules["file_type_rules"][ext] = {
                    "pattern": learning["pattern"],
                    "default_tag": learning["action"],
                    "confidence": learning["confidence"],
                    "created_date": datetime.now().isoformat(),
                    "corrections_count": 0
                }
            
            self.learning_rules["file_type_rules"][ext]["corrections_count"] += 1
        
        elif rule_type == "KEYWORD_RULE":
            keyword = learning["condition"].split("'")[1] if "'" in learning["condition"] else "unknown"
            
            if keyword not in self.learning_rules["keyword_rules"]:
                self.learning_rules["keyword_rules"][keyword] = {
                    "pattern": learning["pattern"],
                    "default_tag": learning["action"],
                    "confidence": learning["confidence"],
                    "created_date": datetime.now().isoformat(),
                    "corrections_count": 0
                }
            
            self.learning_rules["keyword_rules"][keyword]["corrections_count"] += 1
        
        elif rule_type == "SPECIAL_FILE_TYPE":
            if "ChatGPT" not in self.learning_rules["exception_rules"]:
                self.learning_rules["exception_rules"]["ChatGPT"] = {
                    "pattern": learning["pattern"],
                    "default_tag": learning["action"],
                    "confidence": learning["confidence"],
                    "created_date": datetime.now().isoformat(),
                    "corrections_count": 0
                }
            
            self.learning_rules["exception_rules"]["ChatGPT"]["corrections_count"] += 1
        
        self.learning_rules["last_updated"] = datetime.now().isoformat()
        self.learning_rules["total_corrections_learned"] += 1
        
        self._save_rules()
    
    def _save_rules(self):
        """Save learning rules to file"""
        with open(self.rules_file, 'w') as f:
            json.dump(self.learning_rules, f, indent=2)
    
    def apply_learned_rules(self, filename: str, 
                           navi_initial_classification: str) -> Dict:
        """
        Apply learned rules to potentially improve classification
        Called before showing classification to user
        """
        
        filename_lower = filename.lower()
        file_ext = Path(filename).suffix.lower()
        
        improved_classification = navi_initial_classification
        confidence = 0.95  # Default
        
        # Check exception rules first (highest priority)
        for exception_name, rule in self.learning_rules.get("exception_rules", {}).items():
            if exception_name.lower() in filename_lower:
                improved_classification = rule["default_tag"]
                confidence = rule["confidence"]
                return {
                    "original": navi_initial_classification,
                    "improved": improved_classification,
                    "reason": f"Learned rule: {rule['pattern']}",
                    "confidence": confidence,
                    "applied": True
                }
        
        # Check file type rules
        if file_ext in self.learning_rules.get("file_type_rules", {}):
            rule = self.learning_rules["file_type_rules"][file_ext]
            if rule["corrections_count"] >= 2:  # Must have 2+ corrections to trust
                improved_classification = rule["default_tag"]
                confidence = rule["confidence"]
                return {
                    "original": navi_initial_classification,
                    "improved": improved_classification,
                    "reason": f"Learned rule: {rule['pattern']}",
                    "confidence": confidence,
                    "applied": True
                }
        
        # Check keyword rules
        for keyword, rule in self.learning_rules.get("keyword_rules", {}).items():
            if keyword in filename_lower:
                if rule["corrections_count"] >= 2:
                    improved_classification = rule["default_tag"]
                    confidence = rule["confidence"]
                    return {
                        "original": navi_initial_classification,
                        "improved": improved_classification,
                        "reason": f"Learned rule: {rule['pattern']}",
                        "confidence": confidence,
                        "applied": True
                    }
        
        # No learned rule applied
        return {
            "original": navi_initial_classification,
            "improved": navi_initial_classification,
            "reason": "No learned rule applicable",
            "confidence": confidence,
            "applied": False
        }
    
    def get_learning_summary(self) -> Dict:
        """Get summary of what Navi has learned"""
        
        file_type_count = len(self.learning_rules.get("file_type_rules", {}))
        keyword_count = len(self.learning_rules.get("keyword_rules", {}))
        exception_count = len(self.learning_rules.get("exception_rules", {}))
        total_corrections = self.learning_rules.get("total_corrections_learned", 0)
        
        return {
            "total_corrections_learned": total_corrections,
            "file_type_rules": file_type_count,
            "keyword_rules": keyword_count,
            "exception_rules": exception_count,
            "total_rules": file_type_count + keyword_count + exception_count,
            "last_updated": self.learning_rules.get("last_updated"),
            "rules_detail": {
                "file_types": self.learning_rules.get("file_type_rules", {}),
                "keywords": self.learning_rules.get("keyword_rules", {}),
                "exceptions": self.learning_rules.get("exception_rules", {})
            }
        }
    
    def get_improvement_trend(self, sessions: List[Dict]) -> Dict:
        """Calculate improvement trend across sessions"""
        
        if len(sessions) < 2:
            return {"trend": "Insufficient data", "improvement_percent": 0}
        
        # First 50% accuracy
        first_half = sessions[:len(sessions)//2]
        first_accuracy = sum(s.get("metrics", {}).get("navi_accuracy", 100) for s in first_half) / len(first_half)
        
        # Second 50% accuracy
        second_half = sessions[len(sessions)//2:]
        second_accuracy = sum(s.get("metrics", {}).get("navi_accuracy", 100) for s in second_half) / len(second_half)
        
        improvement = second_accuracy - first_accuracy
        
        return {
            "first_half_accuracy": round(first_accuracy, 1),
            "second_half_accuracy": round(second_accuracy, 1),
            "improvement_percent": round(improvement, 1),
            "trend": "📈 Improving" if improvement > 0 else "📉 Declining" if improvement < 0 else "➡️ Stable",
            "rules_learned": self.learning_rules.get("total_corrections_learned", 0)
        }
    
    def format_learning_summary_for_display(self) -> str:
        """Format learning summary for user display"""
        
        summary = self.get_learning_summary()
        
        output = f"""
════════════════════════════════════════════════════
NAVI LEARNING SUMMARY
════════════════════════════════════════════════════

📚 LEARNING PROGRESS:
├─ Corrections learned: {summary['total_corrections_learned']}
├─ Rules created: {summary['total_rules']}
│  ├─ File type rules: {summary['file_type_rules']}
│  ├─ Keyword rules: {summary['keyword_rules']}
│  └─ Special exceptions: {summary['exception_rules']}
└─ Last updated: {summary['last_updated'][:10]}

"""
        
        if summary['rules_detail']['exceptions']:
            output += "✨ SPECIAL RULES LEARNED:\n"
            for name, rule in summary['rules_detail']['exceptions'].items():
                output += f"├─ {name}: {rule['pattern']}\n"
            output += "\n"
        
        output += f"════════════════════════════════════════════════════\n"
        
        return output


if __name__ == "__main__":
    # Test
    learner = AutoLearner()
    
    # Simulate correction
    result = learner.learn_from_correction(
        "chatgpt_conversation_2025-12-09.txt",
        "[24HR]",
        "[STANDARD]",
        "ChatGPT logs have 'action' keyword but shouldn't be marked urgent"
    )
    print("✅ Correction learned!")
    
    # Check if learned rule applies
    application = learner.apply_learned_rules(
        "chatgpt_log_new.txt",
        "[24HR]"
    )
    print(f"📚 Rule application result: {application}")
    
    # Show summary
    print(learner.format_learning_summary_for_display())
