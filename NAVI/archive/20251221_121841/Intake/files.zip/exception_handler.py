#!/usr/bin/env python3
"""
EXCEPTION INTERRUPT HANDLER
Handles urgent/random files that need immediate processing outside batch cycle
"""

import json
from pathlib import Path
from datetime import datetime
from typing import Dict, List, Any
import logging

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

class InterruptHandler:
    """Manages interrupt processing for urgent files"""
    
    def __init__(self, inbox_dir: str, interrupt_log_path: str = None):
        self.inbox_dir = Path(inbox_dir)
        self.interrupt_log = Path(interrupt_log_path) if interrupt_log_path else Path("interrupt_log.json")
        self.interrupt_queue = []
        self.current_batch = None
        self.load_log()
    
    def load_log(self):
        """Load existing interrupt log"""
        if self.interrupt_log.exists():
            with open(self.interrupt_log, 'r') as f:
                self.interrupt_queue = json.load(f)
    
    def handle_interrupt(self, filename: str, priority: str = "IMMEDIATE", 
                        reason: str = "") -> Dict[str, Any]:
        """
        Handle an interrupt - pause batch, process urgent file
        
        Usage: /interrupt filename.pdf
        """
        
        logger.info(f"🚨 INTERRUPT: {filename}")
        
        interrupt_record = {
            "timestamp": datetime.now().isoformat(),
            "filename": filename,
            "priority": priority,
            "reason": reason,
            "batch_paused": self.current_batch is not None,
            "status": "PROCESSING",
            "user_decision": None
        }
        
        # Add to interrupt queue
        self.interrupt_queue.append(interrupt_record)
        
        # Return summary for user
        return {
            "status": "INTERRUPT_MODE_ACTIVE",
            "filename": filename,
            "priority": priority,
            "action": "Processing immediately...",
            "batch_status": f"Batch paused at file {self.get_batch_position()}" if self.current_batch else "No active batch",
            "message": f"Processing {filename} as [{priority}]. Your decision needed when complete."
        }
    
    def process_interrupt_file(self, file_path: Path) -> Dict[str, Any]:
        """Process the interrupt file"""
        
        logger.info(f"Processing interrupt file: {file_path}")
        
        # Classify file
        classification = self._classify_interrupt_file(file_path)
        
        # Extract data
        data = self._extract_interrupt_data(file_path)
        
        return {
            "filename": file_path.name,
            "classification": classification,
            "priority": classification.get("priority"),
            "tag": classification.get("tag"),
            "data": data,
            "confidence": classification.get("confidence", 0.95),
            "recommended_action": classification.get("recommended_action")
        }
    
    def _classify_interrupt_file(self, file_path: Path) -> Dict:
        """Quick classification of interrupt file"""
        
        filename = file_path.name.lower()
        
        # Check for critical keywords
        critical_keywords = ['error', 'critical', 'urgent', 'emergency', 'alert', 'security']
        is_critical = any(kw in filename for kw in critical_keywords)
        
        if is_critical:
            return {
                "classification": "ACTION",
                "priority": "IMMEDIATE",
                "tag": "[IMMEDIATE]",
                "confidence": 0.98,
                "recommended_action": "Act within 1 hour"
            }
        
        # Default to high priority for interrupts
        return {
            "classification": "ACTION",
            "priority": "24HR",
            "tag": "[24HR]",
            "confidence": 0.85,
            "recommended_action": "Review and route"
        }
    
    def _extract_interrupt_data(self, file_path: Path) -> Dict:
        """Extract key data from interrupt file"""
        
        try:
            if file_path.suffix.lower() in ['.txt', '.log']:
                with open(file_path, 'r', encoding='utf-8', errors='ignore') as f:
                    content = f.read(500)
                return {
                    "preview": content,
                    "type": "TEXT",
                    "size": file_path.stat().st_size
                }
        except Exception as e:
            logger.error(f"Error extracting interrupt data: {e}")
        
        return {
            "preview": "Unable to extract",
            "type": file_path.suffix,
            "size": file_path.stat().st_size if file_path.exists() else 0
        }
    
    def get_user_decision(self, filename: str, decision: str, 
                         custom_tag: str = None) -> Dict:
        """
        User makes decision on interrupt file
        
        Decisions: OK, NO, HOLD
        """
        
        logger.info(f"User decision on interrupt: {filename} → {decision}")
        
        # Find the interrupt record
        interrupt = next((i for i in self.interrupt_queue if i["filename"] == filename), None)
        
        if not interrupt:
            return {"error": f"Interrupt not found: {filename}"}
        
        # Update record
        interrupt["user_decision"] = decision
        interrupt["status"] = "DECIDED"
        interrupt["custom_tag"] = custom_tag
        
        # Save log
        self.save_log()
        
        return {
            "status": "INTERRUPT_COMPLETE",
            "filename": filename,
            "decision": decision,
            "action": self._get_action_for_decision(decision, custom_tag),
            "next_step": "Resuming batch processing..."
        }
    
    def _get_action_for_decision(self, decision: str, custom_tag: str = None) -> str:
        """Get action based on user decision"""
        
        if decision == "OK":
            return "File will be moved to appropriate folder"
        elif decision == "NO":
            return "Please specify correct priority/folder"
        elif decision == "HOLD":
            return f"File moved to WAITING with reason"
        else:
            return "Unknown decision"
    
    def resume_batch(self) -> Dict:
        """Resume batch processing after interrupt"""
        
        logger.info("Resuming batch processing...")
        
        return {
            "status": "BATCH_RESUMED",
            "message": "Batch processing resumed from where it paused",
            "pending_interrupts": len([i for i in self.interrupt_queue if i["status"] != "DECIDED"])
        }
    
    def get_batch_position(self) -> int:
        """Get current position in batch"""
        return self.current_batch.get("position", 0) if self.current_batch else 0
    
    def set_batch_status(self, batch_info: Dict):
        """Set current batch info for pause/resume"""
        self.current_batch = batch_info
    
    def get_interrupt_summary(self, period: str = "session") -> Dict:
        """Get summary of interrupts for session/day/week"""
        
        interrupts_in_period = [i for i in self.interrupt_queue if i["status"] == "DECIDED"]
        
        return {
            "total_interrupts": len(interrupts_in_period),
            "by_priority": self._count_by_priority(interrupts_in_period),
            "by_decision": self._count_by_decision(interrupts_in_period),
            "interrupts": interrupts_in_period
        }
    
    def _count_by_priority(self, interrupts: List) -> Dict:
        counts = {}
        for interrupt in interrupts:
            priority = interrupt.get("priority", "UNKNOWN")
            counts[priority] = counts.get(priority, 0) + 1
        return counts
    
    def _count_by_decision(self, interrupts: List) -> Dict:
        counts = {}
        for interrupt in interrupts:
            decision = interrupt.get("user_decision", "UNKNOWN")
            counts[decision] = counts.get(decision, 0) + 1
        return counts
    
    def save_log(self):
        """Save interrupt log to file"""
        with open(self.interrupt_log, 'w') as f:
            json.dump(self.interrupt_queue, f, indent=2)
    
    def clear_old_interrupts(self, days: int = 30):
        """Archive old interrupt records"""
        from datetime import timedelta
        
        cutoff = datetime.now() - timedelta(days=days)
        
        old = []
        recent = []
        
        for interrupt in self.interrupt_queue:
            interrupt_time = datetime.fromisoformat(interrupt["timestamp"])
            if interrupt_time < cutoff:
                old.append(interrupt)
            else:
                recent.append(interrupt)
        
        # Save old to archive
        if old:
            archive_path = self.interrupt_log.parent / f"interrupt_archive_{datetime.now().strftime('%Y-%m')}.json"
            with open(archive_path, 'a') as f:
                json.dump(old, f, indent=2)
        
        # Keep recent
        self.interrupt_queue = recent
        self.save_log()
        
        logger.info(f"Archived {len(old)} old interrupts")


if __name__ == "__main__":
    # Test
    handler = InterruptHandler("D:\\05_AGENTS\\NAVI_RECEPTIONIST\\inbox")
    
    # Simulate interrupt
    result = handler.handle_interrupt("urgent_error.log", "IMMEDIATE", "System error detected")
    print("INTERRUPT HANDLER INITIATED:")
    for key, value in result.items():
        print(f"  {key}: {value}")
    
    # Simulate user decision
    decision = handler.get_user_decision("urgent_error.log", "OK")
    print("\nUSER DECISION PROCESSED:")
    for key, value in decision.items():
        print(f"  {key}: {value}")
    
    # Resume batch
    resume = handler.resume_batch()
    print("\nBATCH RESUMED:")
    for key, value in resume.items():
        print(f"  {key}: {value}")
