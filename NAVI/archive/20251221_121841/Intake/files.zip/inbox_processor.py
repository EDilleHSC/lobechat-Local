#!/usr/bin/env python3
"""
INBOX PROCESSOR - Main orchestrator
Monitors inbox → Classifies files → Extracts data → Generates intelligence JSON
"""

import json
import time
from pathlib import Path
from typing import Dict, List
from datetime import datetime
import logging

# Import our modules
import sys
sys.path.insert(0, str(Path(__file__).parent))

class InboxProcessor:
    """Processes inbox files and generates intelligence knowledge base"""
    
    def __init__(self, inbox_dir: str, output_dir: str = None):
        self.inbox_dir = Path(inbox_dir)
        self.output_dir = Path(output_dir) if output_dir else self.inbox_dir.parent / "intelligence"
        self.output_dir.mkdir(exist_ok=True)
        self.kb_file = self.output_dir / "navi_intelligence.json"
        
        # Setup logging
        logging.basicConfig(
            level=logging.INFO,
            format='%(asctime)s - %(levelname)s - %(message)s',
            handlers=[
                logging.FileHandler(self.output_dir / "processor.log"),
                logging.StreamHandler()
            ]
        )
        self.logger = logging.getLogger(__name__)
    
    def process_inbox(self) -> Dict:
        """Main processing function"""
        
        self.logger.info("🚀 Starting inbox processing...")
        
        if not self.inbox_dir.exists():
            self.logger.error(f"Inbox directory not found: {self.inbox_dir}")
            return {}
        
        # Get all files in inbox
        files = sorted([f for f in self.inbox_dir.iterdir() if f.is_file()])
        self.logger.info(f"Found {len(files)} files in inbox")
        
        # Process each file
        intelligence = {
            "generated_at": datetime.now().isoformat(),
            "inbox_path": str(self.inbox_dir),
            "total_files": len(files),
            "files": [],
            "summary": {
                "urgent": 0,
                "high_priority": 0,
                "medium_priority": 0,
                "action_required": 0,
                "reference_only": 0,
                "ignored": 0
            },
            "routing": {}
        }
        
        for file_path in files:
            try:
                file_intel = self._process_file(file_path)
                intelligence["files"].append(file_intel)
                
                # Update summary
                if file_intel.get("classification") == "ACTION":
                    intelligence["summary"]["action_required"] += 1
                    if file_intel.get("priority") == "URGENT":
                        intelligence["summary"]["urgent"] += 1
                    elif file_intel.get("priority") == "HIGH":
                        intelligence["summary"]["high_priority"] += 1
                    else:
                        intelligence["summary"]["medium_priority"] += 1
                elif file_intel.get("classification") == "REFERENCE":
                    intelligence["summary"]["reference_only"] += 1
                else:
                    intelligence["summary"]["ignored"] += 1
                
                self.logger.info(f"✅ Processed: {file_path.name}")
            except Exception as e:
                self.logger.error(f"❌ Error processing {file_path.name}: {e}")
        
        # Generate routing suggestions
        intelligence["routing"] = self._generate_routing(intelligence["files"])
        
        # Save intelligence to JSON
        self._save_intelligence(intelligence)
        
        self.logger.info("✅ Inbox processing complete!")
        return intelligence
    
    def _process_file(self, file_path: Path) -> Dict:
        """Process a single file"""
        
        filename = file_path.name
        file_size = file_path.stat().st_size
        file_modified = datetime.fromtimestamp(file_path.stat().st_mtime).isoformat()
        
        # Classify file
        classification = self._classify_file(filename)
        
        # Extract data if needed
        data = {}
        if classification.get("process"):
            try:
                data = self._extract_data(file_path)
            except Exception as e:
                data = {"extraction_error": str(e)}
        
        # Build file intelligence
        file_intel = {
            "filename": filename,
            "size_bytes": file_size,
            "modified": file_modified,
            "extension": file_path.suffix,
            "classification": classification.get("classification"),
            "priority": classification.get("priority"),
            "process_type": classification.get("process_type"),
            "summary": data.get("summary", ""),
            "data": data,
        }
        
        return file_intel
    
    def _classify_file(self, filename: str) -> Dict:
        """Classify a file"""
        
        # Ignore list
        ignore_patterns = ['Microsoft.PowerShell_profile', 'profile.ps1', '__pycache__']
        for pattern in ignore_patterns:
            if pattern.lower() in filename.lower():
                return {
                    'classification': 'IGNORE',
                    'priority': 'NONE',
                    'process': False
                }
        
        # Reference only
        reference_patterns = ['GTD_WORKFLOW_GUIDE', 'README', 'TEMPLATE']
        for pattern in reference_patterns:
            if pattern.lower() in filename.lower():
                return {
                    'classification': 'REFERENCE',
                    'priority': 'LOW',
                    'process': True,
                    'process_type': 'READ_ONCE'
                }
        
        # Determine priority
        priority = 'MEDIUM'
        if any(x in filename.lower() for x in ['error', 'urgent', 'critical', 'emergency']):
            priority = 'URGENT'
        elif any(x in filename.lower() for x in ['log', 'debug']):
            priority = 'HIGH'
        
        # Determine process type
        ext = Path(filename).suffix.lower()
        process_type = self._get_process_type(ext, filename)
        
        return {
            'classification': 'ACTION',
            'priority': priority,
            'process': True,
            'process_type': process_type
        }
    
    def _get_process_type(self, ext: str, filename: str) -> str:
        """Get processing type based on extension"""
        
        type_map = {
            '.log': 'EXTRACT_ERRORS',
            '.py': 'ANALYZE_CODE',
            '.pdf': 'EXTRACT_CONTENT',
            '.xlsx': 'EXTRACT_DATA',
            '.csv': 'PARSE_DATA',
            '.txt': 'READ_EXTRACT',
            '.jpg': 'DESCRIBE_IMAGE',
            '.png': 'DESCRIBE_IMAGE',
            '.json': 'PARSE_DATA',
        }
        
        return type_map.get(ext, 'READ_PREVIEW')
    
    def _extract_data(self, file_path: Path) -> Dict:
        """Extract data from file"""
        
        ext = file_path.suffix.lower()
        
        if ext in ['.txt', '.log', '.py', '.ps1', '.md']:
            return self._extract_text(file_path)
        else:
            return {"summary": f"File type {ext} detected"}
    
    def _extract_text(self, file_path: Path) -> Dict:
        """Extract from text files"""
        
        try:
            with open(file_path, 'r', encoding='utf-8', errors='ignore') as f:
                content = f.read(1000)
            
            extracted = {
                "summary": content[:300],
                "length": len(content),
            }
            
            # Look for errors in logs
            if 'log' in file_path.name.lower():
                import re
                errors = re.findall(r'error.*', content, re.IGNORECASE)
                if errors:
                    extracted["errors"] = errors[:3]
            
            return extracted
        except Exception as e:
            return {"error": str(e)}
    
    def _generate_routing(self, files: List[Dict]) -> Dict:
        """Generate routing suggestions for files"""
        
        routing = {
            "urgent_files": [],
            "high_priority": [],
            "to_archive": [],
            "to_escalate": []
        }
        
        for file_intel in files:
            filename = file_intel.get("filename", "")
            priority = file_intel.get("priority", "")
            classification = file_intel.get("classification", "")
            
            if priority == "URGENT":
                routing["urgent_files"].append(filename)
            elif priority == "HIGH":
                routing["high_priority"].append(filename)
            elif classification == "REFERENCE":
                routing["to_archive"].append(filename)
            
            # Check for errors that need escalation
            if "error" in filename.lower() or "critical" in filename.lower():
                routing["to_escalate"].append(filename)
        
        return routing
    
    def _save_intelligence(self, intelligence: Dict):
        """Save intelligence to JSON file"""
        
        with open(self.kb_file, 'w') as f:
            json.dump(intelligence, f, indent=2)
        
        self.logger.info(f"✅ Intelligence saved to: {self.kb_file}")
    
    def get_intelligence(self) -> Dict:
        """Load existing intelligence from file"""
        
        if self.kb_file.exists():
            with open(self.kb_file, 'r') as f:
                return json.load(f)
        return {}


if __name__ == "__main__":
    # Configuration
    INBOX_DIR = r"D:\05_AGENTS\NAVI_RECEPTIONIST\inbox"
    OUTPUT_DIR = r"D:\05_AGENTS\NAVI_RECEPTIONIST\intelligence"
    
    # Process
    processor = InboxProcessor(INBOX_DIR, OUTPUT_DIR)
    intelligence = processor.process_inbox()
    
    # Display summary
    print("\n" + "=" * 60)
    print("INBOX INTELLIGENCE SUMMARY")
    print("=" * 60)
    print(f"Total Files: {intelligence.get('total_files', 0)}")
    print(f"Action Required: {intelligence['summary'].get('action_required', 0)}")
    print(f"Urgent: {intelligence['summary'].get('urgent', 0)}")
    print(f"High Priority: {intelligence['summary'].get('high_priority', 0)}")
    print(f"Reference Only: {intelligence['summary'].get('reference_only', 0)}")
    print(f"Ignored: {intelligence['summary'].get('ignored', 0)}")
    
    if intelligence.get('routing', {}).get('urgent_files'):
        print(f"\n🚨 URGENT FILES:")
        for f in intelligence['routing']['urgent_files']:
            print(f"   - {f}")
