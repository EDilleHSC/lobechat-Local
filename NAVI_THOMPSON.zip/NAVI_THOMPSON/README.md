Navi Thompson is an intake-only agent designed specifically for processing incoming requests and managing operational intake queues. This agent does not perform execution tasks but focuses on intake, routing, and coordination.

Features:
- File-based inbox processing
- Request prioritization
- Professional communication
- Memory and learning capabilities
- Safety and audit logging